from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from db import get_db_connection, ACCOUNT_DB_CONFIG 
from utils import fetch_stock_data  

watchlist_bp = Blueprint('watchlist', __name__)

def get_user_id(username, conn):
    """
    Output the user id of the corresponding username that has been retrieved from the frontend. 

    Args:
        username (str): the username retrieved from the user on the frontend. 
        conn : existing connection to our PostreSQL database. 

    Raises:
        ValueError (str): display error if the username does not match any exisiting usernames in database.

    Returns:
        user id (int): assigned user id to the passed in username. 
    """
    
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM account WHERE username = %s", (username,))
    user = cursor.fetchone()
    cursor.close()
    if not user:
        raise ValueError("User not found")
    return user[0]

def fetch_watchlist_stocks(user_id, conn):
    """
    Retrieve all the stocks that a user added to their watchlist along with the financial information that gets displayed
    for these stocks on the watchlist page on the frontend. 

    Args:
        user_id (int): id that is assigned to the user upon signup.
        conn : existing connection to our PostreSQL database. 

    Returns:
        list of dictionaries: list of stocks along with key attributes for the passed in user id. 
    """
    
    cursor = conn.cursor()
    cursor.execute("SELECT ticker FROM watchlist WHERE user_id = %s", (user_id,))
    tickers = [row[0] for row in cursor.fetchall()]
    cursor.close()
    stocks_data = [data for ticker in tickers if (data := fetch_stock_data(ticker))]
    return stocks_data

@watchlist_bp.route('/', methods=['GET', 'POST'])
@jwt_required()
def index():
    """
    Retrieve a user's watchlist along with updating it i.e. if they add stocks on the frontend.

    Returns:
        JSON status: success
        AND
        JSON list: successfully retrieved stocks of the user and any updates to the original list. 
        OR
        JSON status: error
        AND
        str: error message
    """
    
    username = get_jwt_identity()
    conn = get_db_connection(ACCOUNT_DB_CONFIG)

    try:
        user_id = get_user_id(username, conn)

        if request.method == 'POST':
            ticker = request.form.get('ticker', '').upper().strip()
            if not ticker:
                return jsonify({"status": "error", "error": "Invalid ticker symbol"}), 400

            data = fetch_stock_data(ticker)
            if not data:
                return jsonify({"status": "error", "error": f"{ticker} not found in database"}), 404

            cursor = conn.cursor()
            cursor.execute("SELECT ticker FROM watchlist WHERE user_id = %s AND ticker = %s", (user_id, ticker))
            if cursor.fetchone():
                cursor.close()
                return jsonify({"status": "error", "error": f"{ticker} is already in your watchlist"}), 400

            cursor.execute("INSERT INTO watchlist (user_id, ticker) VALUES (%s, %s)", (user_id, ticker))
            conn.commit()
            cursor.close()

        stocks_data = fetch_watchlist_stocks(user_id, conn)
        conn.close()
        return jsonify({"status": "success", "stocks": stocks_data})

    except ValueError as e:
        conn.close()
        return jsonify({"status": "error", "error": str(e)}), 404
    except Exception as e:
        conn.close()
        return jsonify({"status": "error", "error": f"Server error: {str(e)}"}), 500

@watchlist_bp.route('/remove', methods=['POST'])
@jwt_required()
def remove():
    """
    Deletes a stock from the user's watchlist if they remove it on the frontend.

    Returns:
        JSON status: success 
        AND
        list: new list after removing deleted stocks. 
        OR
        JSON status: error
        AND
        str: error message
    """
    
    username = get_jwt_identity()
    ticker = request.json.get('ticker')
    if not ticker:
        return jsonify({"status": "error", "error": "Ticker is required"}), 400

    conn = get_db_connection(ACCOUNT_DB_CONFIG)

    try:
        user_id = get_user_id(username, conn)

        cursor = conn.cursor()
        cursor.execute("SELECT ticker FROM watchlist WHERE user_id = %s AND ticker = %s", (user_id, ticker))
        if not cursor.fetchone():
            cursor.close()
            conn.close()
            return jsonify({"status": "error", "error": f"{ticker} not in your watchlist"}), 404

        cursor.execute("DELETE FROM watchlist WHERE user_id = %s AND ticker = %s", (user_id, ticker))
        conn.commit()
        cursor.close()

        stocks_data = fetch_watchlist_stocks(user_id, conn)
        conn.close()
        return jsonify({"status": "success", "stocks": stocks_data})

    except ValueError as e:
        conn.close()
        return jsonify({"status": "error", "error": str(e)}), 404
    except Exception as e:
        conn.close()
        return jsonify({"status": "error", "error": f"Server error: {str(e)}"}), 500