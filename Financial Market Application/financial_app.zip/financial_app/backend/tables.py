import pandas as pd
import plotly.graph_objects as go
from pull_data import (
    query_historical_prices, 
    query_financials, 
    query_ratio_ticker
)

def get_valuation_ratios(ticker):
    """
    Calculate and return the valuation ratios for a given ticker over a defined time period.

    This function calculates the following valuation ratios for each quarter in the range:
        - Price/Earnings (P/E)
        - Price/Sales (P/S)
        - Price/Cashflow (P/CF)
        - Price to Book
        - Enterprise Value (EV)
        - EV/EBITDA

    The function uses historical price data, financial data, and ticker-specific data to compute the ratios.

    :param str ticker: The ticker ID for which valuation ratios are to be calculated.
    :return: A list of dictionaries, each containing the calculated ratios for a specific quarter.
    :rtype: list of dict
    """
    price_df = query_historical_prices(ticker)
    financials_df = query_financials(ticker, "2023-01-01", "2024-12-31")
    ticker_df = query_ratio_ticker(ticker)

    # Ensure price and financials are not empty
    if price_df.empty or financials_df.empty:
        print(f"Missing data for {ticker}. One or more time-series DataFrames are empty.")
        return None


    price_df["date"] = pd.to_datetime(price_df["date"])
    financials_df["date"] = pd.to_datetime(financials_df["date"])


    price_df["quarter"] = price_df["date"].dt.to_period("Q")
    last_prices = price_df.groupby("quarter")["close"].last()


    financials_df["quarter"] = financials_df["date"].dt.to_period("Q")
    last_financials = financials_df.groupby("quarter").last()


    all_quarters = pd.period_range(start="2022Q1", end="2023Q4", freq="Q")


    ticker_data = ticker_df.iloc[0].to_dict() if not ticker_df.empty else {}

    # Compute ratios for each quarter
    ratios = []
    for quarter in all_quarters:
        price = last_prices.get(quarter, None)
        eps = last_financials.get("basic_eps", {}).get(quarter, None)
        cash_flow = last_financials.get("cash_flows_from_used_in_operating_activities_direct", {}).get(quarter, None)
        ebitda = last_financials.get("ebitda", {}).get(quarter, None)

        market_cap = ticker_data.get("market_cap", None)
        revenue = last_financials.get("total_revenue", {}).get(quarter, None)
        price_to_book = ticker_data.get("price_to_book", None)
        enterprise_value = ticker_data.get("enterprise_value", None)

        pe_ratio = (price / eps) if price is not None and eps is not None and eps != 0 else None
        ps_ratio = (market_cap / revenue) if market_cap is not None and revenue is not None and revenue != 0 else None
        pcf_ratio = (market_cap / cash_flow) if market_cap is not None and cash_flow is not None and cash_flow != 0 else None
        ev_ebitda_ratio = round((enterprise_value / ebitda), 2) if enterprise_value is not None and ebitda is not None and ebitda != 0 else None

        ratios.append({
            "Quarter": str(quarter),
            "Price/Earnings": pe_ratio,
            "Price/Sales": ps_ratio,
            "Price/Cashflow": pcf_ratio,
            "Price to Book": price_to_book,
            "Enterprise Value": enterprise_value,
            "EV/EBITDA": ev_ebitda_ratio
        })

    return ratios

def create_valuation_table(ticker):
    """
    Create and display a table of quarterly valuation ratios for the specified ticker.

    This function retrieves valuation ratios such as Price/Earnings, Price/Sales,
    Price/Cashflow, Price to Book, Enterprise Value, and EV/EBITDA for a given ticker.
    It then formats the data into a table and shows it using Plotly.

    :param str ticker: The ticker ID for which the valuation table is to be created.
    :return: None
    :rtype: None
    """
    ratios = get_valuation_ratios(ticker)
    if not ratios:
        return

    # Format table data
    header = ["Quarter"] + list(ratios[0].keys())[1:]
    values = [[entry[col] if entry[col] is not None else "-" for entry in ratios] for col in header]

    fig = go.Figure(data=[go.Table(
        header=dict(values=header, fill_color='orangered', align='center', font=dict(size=12, color='black')),
        cells=dict(values=values, fill_color='white', align='center', font=dict(size=12, color='black'))
    )])

    fig.update_layout(
        title=f"Quarterly Valuation Ratios for {ticker}",
        font=dict(family="Arial, sans-serif", size=12),
        height=400
    )

    fig.show()

# Example usage
if __name__ == "__main__":
    create_valuation_table('AGI.AX')