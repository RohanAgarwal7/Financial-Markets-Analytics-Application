import psycopg2 as pg

STOCK_DB_CONFIG = {
    "host": "financial_data",
    "dbname": "stock_data",
    "user": "postgres",
    "password": "postgres",
    "port": "5432"
}

ACCOUNT_DB_CONFIG = {
    "host": "accounts",
    "dbname": "account_data",
    "user": "postgres",
    "password": "postgres",
    "port": "5432"
}

def get_db_connection(config):
    """
    Initiates a connection to the PostgreSQL database our team has set up.

    Args:
        config (dict): A dictionary that contains crucial parameters like host, dbname, user, password and port 
                        which are essential for setting up a successful connection to our databases.

    Returns:
        connection: A connection to the database, if successful.
    """
    return pg.connect(
        host=config["host"],
        user=config["user"],
        password=config["password"],
        dbname=config["dbname"],
        port=config["port"]
    )
