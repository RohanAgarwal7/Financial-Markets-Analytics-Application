from flask import Blueprint, jsonify, redirect, request, url_for
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    jwt_required,
    get_jwt,
    get_jwt_identity,
)
import hashlib
from db import get_db_connection, ACCOUNT_DB_CONFIG
from email_service import send_verification_email
from datetime import timedelta

auth_bp = Blueprint("auth", __name__)
BLOCKLIST = set()

@auth_bp.post("/register")
def register_user():
    """
    Handle user registration by validating input, checking for existing username/email,
    hashing the password, and sending a verification email.

    :return: JSON response indicating the success or failure of the registration process.
    """
    data = request.get_json()
    username = data.get("username")
    email = data.get("email")
    password = data.get("password")

    if not all([username, email, password]):
        return jsonify({"Error": "All fields are required"}), 400

    conn = None
    cursor = None
    try:
        conn = get_db_connection(ACCOUNT_DB_CONFIG)
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM account WHERE username = %s OR email = %s", (username, email))
        if cursor.fetchone():
            return jsonify({"Error": "Username or email already exists"}), 409

        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        verification_token = create_access_token(
            identity=email,
            additional_claims={"type": "email_verification"},
            expires_delta=timedelta(hours=1)
        )

        verification_url = url_for('auth.verify_email', token=verification_token, _external=True)

        cursor.execute(
            "INSERT INTO account (username, email, password, is_verified, verification_token) "
            "VALUES (%s, %s, %s, %s, %s)",
            (username, email, hashed_password, False, verification_token)
        )
        conn.commit()

        try:
            send_verification_email(email, verification_url)
            return jsonify({"message": "User registered successfully"}), 201
        except Exception:
            return jsonify({
                "message": "User registered successfully, but failed to send verification email"
            }), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@auth_bp.get("/verify-email/<token>")
def verify_email(token):
    """
    Verify the user's email by validating the provided token, updating the account status,
    and redirecting to the login page.

    :param token: The email verification token.
    :return: JSON response indicating success or failure, or a redirect to the login page.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection(ACCOUNT_DB_CONFIG)
        cursor = conn.cursor()

        cursor.execute("SELECT id, is_verified FROM account WHERE verification_token = %s", (token,))
        account = cursor.fetchone()

        if not account:
            return jsonify({"error": "Invalid or expired token"}), 400

        if account[1]:
            return jsonify({"message": "Email is already verified"}), 200

        cursor.execute(
            "UPDATE account SET is_verified = TRUE, verification_token = NULL WHERE id = %s",
            (account[0],)
        )
        conn.commit()
        return redirect("http://localhost:3000/login")

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@auth_bp.route("/login", methods=['GET', 'POST'])
def login_user():
    """
    Handles user login by verifying the credentials, checking email verification, and returning access
    and refresh tokens on success. If the credentials are invalid, it returns an error message.

    :return: JSON response with login status or error message.
    """
    if request.method == 'GET':
        return jsonify({"message": "Please use POST to login"}), 200

    data = request.get_json()
    username_or_email = data.get("username")
    password = data.get("password")

    if not all([username_or_email, password]):
        return jsonify({"error": "Username or email and password are required"}), 400

    conn = None
    cursor = None
    try:
        conn = get_db_connection(ACCOUNT_DB_CONFIG)
        cursor = conn.cursor()

        cursor.execute(
            "SELECT id, username, email, password, is_verified FROM account WHERE username = %s OR email = %s",
            (username_or_email, username_or_email)
        )
        user = cursor.fetchone()

        if not user:
            return jsonify({"error": "User not found"}), 404

        if not user[4]:
            return jsonify({"error": "Please verify your email first"}), 403

        if hashlib.sha256(password.encode()).hexdigest() != user[3]:
            return jsonify({"error": "Invalid password"}), 401

        access_token = create_access_token(identity=user[1])
        refresh_token = create_refresh_token(identity=user[1])
        return jsonify({
            "message": "Login successful",
            "tokens": {"access": access_token, "refresh": refresh_token}
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@auth_bp.get("/usersdetails")
@jwt_required()
def whoami():
    """
    Retrieves the details (username and email) of the currently authenticated user
    based on the JWT identity. Returns user details or an error if the user is not found.

    :return: JSON response with user details or error message.
    """
    username = get_jwt_identity()
    conn = None
    cursor = None
    try:
        conn = get_db_connection(ACCOUNT_DB_CONFIG)
        cursor = conn.cursor()

        cursor.execute("SELECT username, email FROM account WHERE username = %s", (username,))
        user = cursor.fetchone()

        if not user:
            return jsonify({"error": "User not found"}), 404

        return jsonify({
            "user_details": {"username": user[0], "email": user[1]}
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@auth_bp.get("/refresh")
@jwt_required(refresh=True)
def refresh_access():
    """
    Refreshes the access token for the authenticated user using a valid refresh token.
    Returns a new access token.

    :return: JSON response with new access token.
    """
    identity = get_jwt_identity()
    new_access_token = create_access_token(identity=identity)
    return jsonify({"access_token": new_access_token}), 200

@auth_bp.get("/logout")
@jwt_required(verify_type=False)
def logout_user():
    """
    Logs out the user by adding the JWT to the blocklist - invalidating it.

    :return: JSON response confirming logout.
    """
    jti = get_jwt()["jti"]
    BLOCKLIST.add(jti)
    return jsonify({"message": "Successfully logged out"}), 200
