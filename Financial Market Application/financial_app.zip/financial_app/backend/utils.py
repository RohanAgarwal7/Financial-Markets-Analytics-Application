from pull_data import query_historical_prices

def fetch_stock_data(ticker): 
    """
    Retrieve ticker attributes like ticker id, close, open, high, low prices. Apply transformations like user friendly formatting
    of 4 decimal places and a calculated price change percentage. 

    Args:
        ticker (str): the universal ticker id used for a particular stock.

    Returns:
        dict: an information dictionary for the passed in ticker that contains ticker, price, price change percentage, high and low, 
                along with any formatting like 4 decmial places.
        OR
        None, if information for the specified ticker could not be retrieved.
    """
    
    df = query_historical_prices(ticker)
    if not df.empty:
        try:
            required_columns = {'ticker_id', 'close', 'open', 'high', 'low'}
            available_columns = set(df.columns.str.lower())
            if not required_columns.issubset(available_columns):
                print(f"Missing columns for {ticker}: {required_columns - available_columns}")
                return None

            latest = df.iloc[-1]
            ticker = latest['ticker_id']
            price = float(latest['close']) 
            prev_close = float(latest['open'])  
            high = float(latest['high'])  
            low = float(latest['low'])  

            change = price - prev_close
            change_pct = (change / prev_close) * 100 if prev_close else 0

            return {
                'ticker': ticker,
                'price': f'${price:.4f}',
                'change_pct': change_pct,
                'high': f'${high:.4f}',
                'low': f'${low:.4f}'
            }
        except (KeyError, ValueError) as e:
            print(f"Error processing data for {ticker}: {e}")
            return None
    else:
        print(f"No data found for {ticker} in database")
        return None
    
