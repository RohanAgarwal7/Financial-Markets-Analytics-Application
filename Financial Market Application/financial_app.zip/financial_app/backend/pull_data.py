import pandas as pd
import psycopg2 as pg
import yfinance as yf

HOSTNAME="financial_data"
DATABASE='stock_data'
USERNAME='postgres'
PASSWORD='postgres'
PORT='5432'

def get_db_connection():
    return pg.connect(
        host=HOSTNAME,
        user=USERNAME,
        password=PASSWORD,
        dbname=DATABASE,
        port=PORT
    )

def query_ticker_long_name(ticker):
    """
    Query the long name of a ticker from the database.

    :param str ticker: The ticker ID to query.
    :return: The long name of the ticker, or None if not found.
    :rtype: str or None
    """
    conn = get_db_connection()
    query = """
        SELECT long_name
        FROM ticker
        WHERE ticker_id = %s
        LIMIT 1
    """
    df = pd.read_sql(query, conn, params=(ticker,))
    conn.close()
    return df['long_name'].iloc[0] if not df.empty else None

def query_historical_prices(ticker):
    """
    Query historical price data for a given ticker from the database.

    :param str ticker: The ticker ID to query historical prices for.
    :return: A DataFrame containing historical price data for the ticker.
    :rtype: pandas.DataFrame
    """
    conn = get_db_connection()
    query = """
        select *
        from historical_price_data
        where ticker_id = '{ticker}'
    """.format(ticker=ticker)

    df = pd.read_sql(query, conn)
    conn.close()
    return df

def query_balance_sheet(ticker, start_date, end_date):
    """
    Query balance sheet data for a given ticker and date range from the database.

    :param str ticker: The ticker ID to query balance sheet data for.
    :param str start_date: The start date for the date range (format: 'YYYY-MM-DD').
    :param str end_date: The end date for the date range (format: 'YYYY-MM-DD').
    :return: A DataFrame containing balance sheet data for the ticker within the specified date range.
    :rtype: pandas.DataFrame
    """
    conn = get_db_connection()
    query = """
        select *
        from balance_sheet
        where ticker_id = '{ticker}'
        and date >= '{start_date}'
        and date <= '{end_date}'
    """.format(ticker=ticker, start_date=start_date, end_date=end_date)

    df = pd.read_sql(query, conn)
    conn.close()
    return df

def query_ratio_ticker(ticker):
    """
    Query ticker data for a given ticker ID from the database.

    :param str ticker: The ticker ID to query data for.
    :return: A DataFrame containing ticker data for the given ticker ID.
    :rtype: pandas.DataFrame
    """
    conn = get_db_connection()
    query = """
        select *
        from ticker
        where ticker_id = '{ticker}'
    """.format(ticker=ticker)

    df = pd.read_sql(query, conn)
    conn.close()
    return df

def query_financials(ticker, start_date, end_date):
    """
    Query financial data for a given ticker ID and date range from the database.

    :param str ticker: The ticker ID to query financial data for.
    :param str start_date: The start date of the range to query financial data for (in 'YYYY-MM-DD' format).
    :param str end_date: The end date of the range to query financial data for (in 'YYYY-MM-DD' format).
    :return: A DataFrame containing financial data for the given ticker ID and date range.
    :rtype: pandas.DataFrame
    """
    conn = get_db_connection()
    query = """
        select *
        from financials
        where ticker_id = '{ticker}'
        and date >= '{start_date}'
        and date <= '{end_date}'
    """.format(ticker=ticker, start_date=start_date, end_date=end_date)

    df = pd.read_sql(query, conn)
    conn.close()
    return df
