from flask import Flask, get_flashed_messages, request, jsonify, render_template, redirect, url_for, flash
from flask_cors import CORS
import psycopg2 as pg
import hashlib
from tables import create_valuation_table
from plots import create_candlestick_chart
from pull_data import query_ticker_long_name
from utils import fetch_stock_data
import re
import secrets
import os
from flask_jwt_extended import JWTManager, jwt_required, get_jwt_identity
from auth import auth_bp, BLOCKLIST
from dotenv import load_dotenv
from db import get_db_connection, STOCK_DB_CONFIG, ACCOUNT_DB_CONFIG
from chatbot import Chatbot
from watchlist import watchlist_bp
import pandas as pd

chatbot = Chatbot()


app = Flask(__name__)
CORS(app)

app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY')
jwt = JWTManager(app)

CORS(auth_bp)
app.register_blueprint(auth_bp, url_prefix='/auth')
app.register_blueprint(watchlist_bp)

@jwt.token_in_blocklist_loader
def check_if_token_revoked(jwt_header, jwt_payload):
    return jwt_payload['jti'] in BLOCKLIST

app.secret_key = secrets.token_hex(16)

@app.route('/api/tickers', methods=['GET'])
def get_tickers():
    """
    Retrieve a list of tickers with optional filtering and sorting.

    :param str marketCap: (Query param) Filter by market cap category ('small', 'mid', 'large').
    :param str industry: (Query param) Filter by industry name.
    :param str sentiment: (Query param) Filter by sentiment label.
    :param str sortField: (Query param) Field to sort by ('ticker_id', 'long_name', 'market_cap', 'industry', 'sentiment').
    :param str sortOrder: (Query param) Sort order ('asc' or 'desc').
    :return: A JSON list of tickers with fields: ticker_id, long_name, market_cap, industry, sentiment.
    :rtype: flask.Response
    """
    try:
        conn = get_db_connection(STOCK_DB_CONFIG)
        cursor = conn.cursor()

        market_cap = request.args.get('marketCap', '')
        industry = request.args.get('industry', '')
        sentiment = request.args.get('sentiment', '')
        sort_field = request.args.get('sortField', 'ticker_id')
        sort_order = request.args.get('sortOrder', 'asc')

        query = """
            SELECT t.ticker_id, t.long_name, t.market_cap, t.industry, ts.sentiment
            FROM ticker t
            LEFT JOIN ticker_sentiment ts ON t.ticker_id = ts.ticker_id
            WHERE 1=1
        """
        params = []

        if market_cap:
            if market_cap == 'small':
                query += " AND t.market_cap < %s"
                params.append(2000000000)
            elif market_cap == 'mid':
                query += " AND t.market_cap BETWEEN %s AND %s"
                params.extend([2000000000, 10000000000])
            elif market_cap == 'large':
                query += " AND t.market_cap > %s"
                params.append(10000000000)

        if industry:
            query += " AND t.industry = %s"
            params.append(industry)

        if sentiment:
            query += " AND ts.sentiment = %s"
            params.append(sentiment)

        allowed_sort_fields = ['ticker_id', 'long_name', 'market_cap', 'industry', 'sentiment']
        if sort_field not in allowed_sort_fields:
            sort_field = 'ticker_id'
        sort_order = 'ASC' if sort_order.lower() == 'asc' else 'DESC'
        
        field_mapping = {
            'ticker_id': 't.ticker_id',
            'long_name': 't.long_name',
            'market_cap': 't.market_cap',
            'industry': 't.industry',
            'sentiment': 'ts.sentiment'
        }
        query += f" ORDER BY {field_mapping[sort_field]} {sort_order}"

        cursor.execute(query, params)
        tickers = cursor.fetchall()
        cursor.close()
        conn.close()

        return jsonify([
            {
                "ticker_id": row[0],
                "long_name": row[1],
                "market_cap": row[2],
                "industry": row[3],
                "sentiment": row[4] if row[4] else "No Sentiment"
            }
            for row in tickers
        ])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/industries', methods=['GET'])
def get_unique_industries():
    """
    Retrieve a list of unique industries from the ticker database.

    :return: A JSON list of unique industry names sorted alphabetically.
    :rtype: flask.Response
    """
    try:
        conn = get_db_connection(STOCK_DB_CONFIG)
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT industry FROM ticker WHERE industry IS NOT NULL ORDER BY industry ASC;")
        industries = [row[0] for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return jsonify(industries)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/visualise/<ticker>', methods=['GET'])
def visualise(ticker):
   """
    Generate and return a candlestick chart for a given ticker.

    :param str ticker: The ticker symbol to visualise.
    :return: A JSON representation of the candlestick chart or an error message.
    :rtype: flask.Response
    """
   try:
       fig = create_candlestick_chart(ticker)
       graph_json = fig.to_json()
       return jsonify(graph_json)
   except Exception as e:
       return jsonify({"error": str(e)}), 500

@app.route('/table/<ticker>', methods=['GET'])
def display_table(ticker):
    """
    Generate and return a valuation table for a given ticker.

    :param str ticker: The ticker symbol to generate the valuation table for.
    :return: A JSON list of table rows representing valuation data or an error message.
    :rtype: flask.Response
    """
    try:
        table = create_valuation_table(ticker)
        table_json = table.to_dict(orient="records")  
        return jsonify(table_json)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/chat', methods=['POST'])
def chatbot_query():
    """
    Process a chatbot query and return a generated response.

    :param dict request.json: JSON body containing a 'query' string from the user.
    :return: A JSON object with the chatbot's response.
    :rtype: flask.Response
    """
    data = request.json
    query = data['query']

    # Extract ticker from query if present (e.g., "What's the price of 1AD.AX?")
    ticker_id = None
    ticker_long_name = None
    for word in query.split():
        if re.match(r'^[A-Z0-9]+\.(AX|US)$', word.upper()):  # Adjust regex for supported exchanges
            ticker_id = word.upper()
            ticker_long_name = query_ticker_long_name(ticker_id)
            break

    # If no ticker is found, use defaults
    if not ticker_id:
        ticker_id = "N/A"
        ticker_long_name = "General Query"

    chat_output = chatbot.getOutput(query, ticker_id, ticker_long_name)
    return jsonify({"output": chat_output})


@app.route('/market-trends', methods=['GET'])
def get_market_trends():
   """
    Retrieve the current market outlook based on recent news using the chatbot.

    :return: A JSON object containing the chatbot's market outlook response or an error message.
    :rtype: flask.Response
    """
   try:
       chatbot = Chatbot()
       response = chatbot.getOutput("What is the current outlook of the market based on recent news?", "", "")
       return jsonify({"response": response})
   except Exception as e:
       print(e, flush=True)
       return jsonify({'error': str(e)}), 500

@app.route('/macro-news', methods=['GET'])
def get_macro_news():
   """
    Retrieve the 5 most recent macroeconomic news articles from the database.

    :return: A JSON list of articles with fields: title, published date, and URL.
    :rtype: flask.Response
    """
   try:
       conn = get_db_connection(STOCK_DB_CONFIG)
       cursor = conn.cursor()
       cursor.execute("SELECT title, published, url FROM macro_news ORDER BY published DESC LIMIT 5")
       rows = cursor.fetchall()
       cursor.close()
       conn.close()


       return jsonify([
           {"title": row[0], "published": row[1], "url": row[2]}
           for row in rows
       ])
   except Exception as e:
       return jsonify({'error': str(e)}), 500

@app.route('/api/stock_details/<ticker>', methods=['GET'])
def get_stock_details(ticker):
    """
    Retrieve stock details and sentiment data for a given ticker.

    :param str ticker: The ticker symbol to fetch data for.
    :return: A JSON object with market price, market cap, shares outstanding, sentiment, and confidence, or an error message.
    :rtype: flask.Response
    """
    conn = get_db_connection(STOCK_DB_CONFIG)
    cursor = conn.cursor()

    # Query to get stock details and sentiment data from both ticker and ticker_sentiment tables
    cursor.execute("""
        SELECT t.regular_market_price, t.market_cap, t.shares_outstanding, ts.sentiment, ts.confidence
        FROM ticker t
        LEFT JOIN ticker_sentiment ts ON t.ticker_id = ts.ticker_id
        WHERE t.ticker_id = %s
    """, (ticker,))

    stock_details = cursor.fetchone()
    cursor.close()
    conn.close()

    if stock_details:
        price, market_cap, shares_outstanding, sentiment, confidence = stock_details

        # Set default values if sentiment or confidence are None or empty
        sentiment = sentiment if sentiment and sentiment.strip() else "No Sentiment"
        confidence = confidence if confidence is not None else 0

        return jsonify({
            "regular_market_price": price,
            "market_cap": market_cap,
            "shares_outstanding": shares_outstanding,
            "sentiment": sentiment,
            "confidence": confidence
        })
    else:
        return jsonify({"error": "Stock details not found"}), 404


@app.route('/api/financial_ratios/<ticker>', methods=['GET'])
def get_financial_ratios(ticker):
    """
    Retrieve and calculate financial ratios for a given ticker.

    :param str ticker: The ticker symbol to fetch financial data for.
    :return: A JSON object with calculated financial ratios (current ratio, cash ratio, debt ratio, debt-to-equity, return on assets, return on equity) and basic EPS, or an error message.
    :rtype: flask.Response
    """
    conn = get_db_connection(STOCK_DB_CONFIG)
    cursor = conn.cursor()

    # Get the data required for financial ratios
    cursor.execute("""
        SELECT
            b.cash_and_cash_equivalents,
            b.current_liabilities,
            b.total_liabilities_net_minority_interest,
            b.total_assets,
            b.stockholders_equity,
            f.net_income,
            f.basic_eps
        FROM
            balance_sheet AS b
        JOIN
            financials AS f
        ON
            b.ticker_id = f.ticker_id
        WHERE
            b.ticker_id = %s
        ORDER BY b.date DESC LIMIT 1
    """, (ticker,))

    result = cursor.fetchone()
    cursor.close()
    conn.close()

    if result:
        # Destructure the result to match what we need
        cash_and_cash_equivalents, current_liabilities, total_liabilities, total_assets, stockholders_equity, net_income, basic_eps = result

        # Calculate financial ratios
        current_ratio = current_liabilities / total_assets if total_assets else None
        debt_to_equity = total_liabilities / stockholders_equity if stockholders_equity else None
        cash_ratio = cash_and_cash_equivalents / current_liabilities if current_liabilities else None
        debt_ratio = total_liabilities / total_assets if total_assets else None
        return_on_assets = net_income / total_assets if total_assets else None
        return_on_equity = net_income / stockholders_equity if stockholders_equity else None

        return jsonify({
            "current_ratio": current_ratio,
            "cash_ratio": cash_ratio,
            "debt_ratio": debt_ratio,
            "debt_to_equity": debt_to_equity,
            "return_on_assets": return_on_assets,
            "return_on_equity": return_on_equity,
            "basic_eps": basic_eps
        })
    else:
        return jsonify({"error": "Financial data not found"}), 404

@app.route('/api/technical_indicators/<ticker>', methods=['GET'])
def get_technical_indicators_route(ticker):
    """
    Retrieve and calculate technical indicators (SMA, RSI, MACD) for a given ticker.

    :param str ticker: The ticker symbol to fetch historical price data for.
    :return: A JSON object with calculated technical indicators (SMA_20, RSI_14, MACD, MACD_signal), or an error message if data is not found.
    :rtype: flask.Response
    """
    # Connect to database
    conn = get_db_connection(STOCK_DB_CONFIG)
    query = """
        SELECT date, close
        FROM historical_price_data
        WHERE ticker_id = %s
        ORDER BY date ASC
    """
    df = pd.read_sql(query, conn, params=(ticker,))
    conn.close()

    if df.empty:
        return jsonify({"error": "Financial data not found"}), 404

    # Define compute_rsi inside the route
    def compute_rsi(series, period=14):
        delta = series.diff()
        gain = delta.where(delta > 0, 0).rolling(window=period).mean()
        loss = -delta.where(delta < 0, 0).rolling(window=period).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))

    # Define compute_macd inside the route
    def compute_macd(series, short=12, long=26, signal=9):
        ema_short = series.ewm(span=short, adjust=False).mean()
        ema_long = series.ewm(span=long, adjust=False).mean()
        macd = ema_short - ema_long
        signal_line = macd.ewm(span=signal, adjust=False).mean()
        return macd, signal_line

    # Calculate indicators
    df["sma_20"] = df["close"].rolling(window=20).mean()
    df["rsi_14"] = compute_rsi(df["close"])
    df["macd"], df["macd_signal"] = compute_macd(df["close"])

    # Get latest complete values
    latest = df.dropna().iloc[-1]

    # Return as JSON
    return jsonify({
        "SMA_20": round(float(latest["sma_20"]), 2),
        "RSI_14": round(float(latest["rsi_14"]), 2),
        "MACD": round(float(latest["macd"]), 2),
        "MACD_signal": round(float(latest["macd_signal"]), 2),
    })


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
