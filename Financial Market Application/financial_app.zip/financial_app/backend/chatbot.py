import chromadb
import torch
from huggingface_hub import login
import os
from datetime import datetime, timedelta
import requests
import json
from db import get_db_connection, STOCK_DB_CONFIG
import google.generativeai as genai
import re

# Logging into HuggingFace to access Chatbot Model - Llama 3.3 70B Instruct
login(token=os.getenv('HF_TOKEN'))

# Logging into google AI to access Gemini 2.0 flash for text-to-sql
GEMINI_TOKEN = os.getenv('GEMINI_TOKEN')
genai.configure(api_key=GEMINI_TOKEN)



def clean_sql_query(query):
    """
    Formats and sanitizes raw text to extract a valid SQL SELECT query.

    Args:
        query (str): Raw text that potentially contains an SQL SELECT query.

    Raises:
        ValueError: If no valid SELECT statement ending with a semicolon is found.

    Returns:
        str: A clean SQL query string extracted from the input.
    """
    match = re.search(r"(SELECT.*?;)", query, re.DOTALL)
    if match:
        return match.group(1).strip()
    else:
        raise ValueError("Invalid SQL query format.")


# Prompt used for LLM RAG Chatbot
prompt = """
            You are TradingAssist, a RAG chatbot for a financial app that has a matter of fact tone. 
            You will be given long paragraphs of context and a question at the end.
            - Output a clear, direct answer to the question with relevant elaboration.
            - Format your response with appropriate headings if multiple aspects need to be covered.
            - The answer should not be making references to the provided contexts.
            - If the question asks for an opinion or speculative information, respond with factual data where possible.
        """

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# Huggingface Inference Client Version Below (Text to SQL Capability)
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------

from huggingface_hub import InferenceClient

# Connection to InferenceClient on HuggingFaceHub
client = InferenceClient(
    provider="sambanova",
    api_key=os.getenv('HF_TOKEN'),
)

class Chatbot:
    def __init__(self):
        """
        Creates a connection with ChromaDB and retrieves the collection for RAG.

        Initialises gemini AI model
        """        
        self.chroma_client = chromadb.HttpClient(host='chromadb', port=8000)

        collection_name = "data"
        try:
            self.collection = self.chroma_client.get_or_create_collection(
                collection_name,
                metadata={"hnsw:space": "cosine"}
            )
            print("Connection established", flush=True)
        except Exception as e:
            print(f"Error creating or accessing collection: {e}")


        self.model = genai.GenerativeModel("gemini-2.0-flash")  

        print("Init complete")

    def getSQLQuery(self, query):
        """
        Converts a user's query to chatbot into a relevant SQL Query using Gemini 2.0 flash model.

        Args:
            query (str): user's input to chatbot

        Returns:
            string: An unformatted SQL Query, or 'No suitable query.'
        """        
        
        response = self.model.generate_content(
            f"""  
            You will be converting a question into a PostgreSQL query for a PostgreSQL database that relates to finance and tickers. 
            The ticker name in the query may not be a 100% match with the long_name in the database. 
            Instead, guess the ticker's SYMBOL before querying relevant content which can be done with ticker_id.
            Technical indicators only contain values for MA5, MA20, MACD and stochastic.
            Below is the database.
            create table ticker (
                ticker_id VARCHAR(10) PRIMARY KEY,
                exchange VARCHAR(50),
                currency VARCHAR(10),
                long_name VARCHAR(255),
                phone VARCHAR(50),
                website VARCHAR(255),
                industry VARCHAR(100),
                sector VARCHAR(100),
                long_business_summary TEXT,
                market_cap BIGINT,
                enterprise_value BIGINT,
                shares_outstanding BIGINT,
                float_shares BIGINT,
                held_percent_insiders DECIMAL(4, 3),
                held_percent_institutions DECIMAL(4, 3),
                book_value BIGINT,
                price_to_book DECIMAL(9, 3),
                total_cash BIGINT,
                total_debt BIGINT,
                total_revenue BIGINT,
                net_income_to_common DECIMAL(17, 2),
                trailing_eps DECIMAL(9, 3),
                beta DECIMAL(9, 3),
                current_ratio DECIMAL(9, 3),
                quick_ratio DECIMAL(9, 3),
                gross_margins DECIMAL(5, 3),
                operating_margins DECIMAL(12, 3),
                regular_market_price DECIMAL(10, 4),
                regular_market_change_percent DECIMAL(5, 2),
                fifty_two_week_low DECIMAL(10, 4),
                fifty_two_week_high DECIMAL(10, 4),
                fifty_day_average DECIMAL(12, 5),
                two_hundred_day_average DECIMAL(12, 5),
                average_volume BIGINT,
                volume BIGINT
            );

            create table balance_sheet (
                ticker_id VARCHAR(10),
                date DATE,
                ordinary_shares_number DECIMAL(15, 0),
                share_issued DECIMAL(15, 0),
                tangible_book_value DECIMAL(17, 2),
                invested_capital DECIMAL(17, 2),
                working_capital DECIMAL(17, 2),
                net_tangible_assets DECIMAL(17, 2),
                common_stock_equity DECIMAL(17, 2),
                total_capitalization DECIMAL(17, 2),
                total_equity_gross_minority_interest DECIMAL(17, 2),
                stockholders_equity DECIMAL(17, 2),
                gains_losses_not_affecting_retained_earnings DECIMAL(17, 2),
                other_equity_adjustments DECIMAL(17, 2),
                retained_earnings DECIMAL(17, 2),
                capital_stock DECIMAL(17, 2),
                common_stock DECIMAL(17, 2),
                total_liabilities_net_minority_interest DECIMAL(17, 2),
                total_non_current_liabilities_net_minority_interest DECIMAL(17, 2),
                current_liabilities DECIMAL(17, 2),
                payables_and_accrued_expenses DECIMAL(17, 2),
                payables DECIMAL(17, 2),
                other_payable DECIMAL(17, 2),
                accounts_payable DECIMAL(17, 2),
                total_assets DECIMAL(17, 2),
                total_non_current_assets DECIMAL(17, 2),
                net_ppe DECIMAL(17, 2),
                gross_ppe DECIMAL(17, 2),
                machinery_furniture_equipment DECIMAL(17, 2),
                current_assets DECIMAL(17, 2),
                receivables DECIMAL(17, 2),
                other_receivables DECIMAL(17, 2),
                accounts_receivable DECIMAL(17, 2),
                cash_cash_equivalents_and_short_term_investments DECIMAL(17, 2),
                cash_and_cash_equivalents DECIMAL(17, 2),
                cash_equivalents DECIMAL(17, 2),
                cash_financial DECIMAL(17, 2),
                PRIMARY KEY (ticker_id, date)
            );

            create table financials (
                ticker_id VARCHAR(10),
                date DATE,
                tax_effect_of_unusual_items DECIMAL(17, 2),
                tax_rate_for_calcs DECIMAL(5, 4),
                normalized_ebitda DECIMAL(17, 2),
                net_income_from_continuing_operation_net_minority_interest DECIMAL(17, 2),
                reconciled_depreciation DECIMAL(17, 2),
                ebitda DECIMAL(17, 2),
                ebit DECIMAL(17, 2),
                normalized_income DECIMAL(17, 2),
                net_income_from_continuing_and_discontinued_operations DECIMAL(17, 2),
                diluted_average_shares DECIMAL(17, 2),
                basic_average_shares DECIMAL(17, 2),
                diluted_eps DECIMAL(15, 4),
                basic_eps DECIMAL(15, 4),
                net_income_common_stockholders DECIMAL(17, 2),
                net_income DECIMAL(17, 2),
                net_income_including_noncontrolling_interests DECIMAL(17, 2),
                net_income_continuous_operations DECIMAL(17, 2),
                tax_provision DECIMAL(17, 2),
                pretax_income DECIMAL(17, 2),
                other_income_expense DECIMAL(17, 2),
                other_non_operating_income_expenses DECIMAL(17, 2),
                operating_income DECIMAL(17, 2),
                operating_expense DECIMAL(17, 2),
                other_operating_expenses DECIMAL(17, 2),
                depreciation_amortization_depletion_income_statement DECIMAL(17, 2),
                depreciation_and_amortization_in_income_statement DECIMAL(17, 2),
                depreciation_income_statement DECIMAL(17, 2),
                selling_general_and_administration DECIMAL(17, 2),
                general_and_administrative_expense DECIMAL(17, 2),
                other_gand_a DECIMAL(17, 2),
                salaries_and_wages DECIMAL(17, 2),
                PRIMARY KEY (ticker_id, date)
            );

            create table cash_flow (
                ticker_id VARCHAR(10),
                date DATE,
                free_cash_flow DECIMAL(17, 2),
                repurchase_of_capital_stock DECIMAL(17, 2),
                issuance_of_debt DECIMAL(17, 2),
                issuance_of_capital_stock DECIMAL(17, 2),
                capital_expenditure DECIMAL(17, 2),
                end_cash_position DECIMAL(17, 2),
                beginning_cash_position DECIMAL(17, 2),
                effect_of_exchange_rate_changes DECIMAL(17, 2),
                changes_in_cash DECIMAL(17, 2),
                financing_cash_flow DECIMAL(17, 2),
                cash_flow_from_continuing_financing_activities DECIMAL(17, 2),
                net_common_stock_issuance DECIMAL(17, 2),
                common_stock_payments DECIMAL(17, 2),
                common_stock_issuance DECIMAL(17, 2),
                net_issuance_payments_of_debt DECIMAL(17, 2),
                net_long_term_debt_issuance DECIMAL(17, 2),
                long_term_debt_issuance DECIMAL(17, 2),
                investing_cash_flow DECIMAL(17, 2),
                cash_flow_from_continuing_investing_activities DECIMAL(17, 2),
                net_ppe_purchase_and_sale DECIMAL(17, 2),
                purchase_of_ppe DECIMAL(17, 2),
                cash_flows_from_used_in_operating_activities_direct DECIMAL(17, 2),
                interest_received_direct DECIMAL(17, 2),
                classes_of_cash_payments DECIMAL(17, 2),
                other_cash_payments_from_operating_activities DECIMAL(17, 2),
                payments_to_suppliers_for_goods_and_services DECIMAL(17, 2),
                classes_of_cash_receipts_from_operating_activities DECIMAL(17, 2),
                other_cash_receipts_from_operating_activities DECIMAL(17, 2),
                PRIMARY KEY (ticker_id, date)
            );

            create table historical_price_data (
                ticker_id VARCHAR(10),
                date DATE,
                open DECIMAL(18, 4),
                high  DECIMAL(18, 4),
                low DECIMAL(18, 4),
                close DECIMAL(18, 4),
                volume BIGINT,
                PRIMARY KEY (ticker_id, date)
            );

            create table technical_indicator (
                ticker_id VARCHAR(10),
                date DATE,
                value DECIMAL(12, 3),
                indicator VARCHAR(32), # possible values are MA5, MA20, MACD, stochastic
                PRIMARY KEY (ticker_id, date, indicator)
            );

            create table ticker_sentiment (
                ticker_id VARCHAR(10),
                sentiment TEXT,
                confidence DECIMAL(7, 4),
                num_articles_analysed INT,
                PRIMARY KEY (ticker_id)
            );

            When replying, please only provide the PostgreSQL Query. Please limit the number of results to 50 in order to not have too many tokens.
            If there is no suitable query, say the exact words "No suitable query.".
            
            The query is: {query}"""#,
            # generation_config={
            #     "temperature": 0.5,
            # }
        )

        print(response.text, flush=True)
        return response.text

    
    def processInput(self, query, ticker_long_name, n_results, metadata_condition):
        """
        Retrieve n relevant texts from chromadb when given a user query. 
        Metadata_condition specifies the type of data to filter

        Args:
            query (str): user's input to chatbot
            ticker_long_name (str): The full name of the ticker to prepend to the query for domain-specific retrieval.
            n_results (int): number of results to query for from chromaDB collection
            metadata_condition (dict): A dictionary specifying metadata filters
            using ChromaDB's Mongo-like syntax (e.g., {"$and": [{"key": {"$gt": value}}, ...]}).

        Returns:
            list: A list of relevant documents from ChromaDB.
        """        
        database_query_prepend = ticker_long_name + ": "

        results = self.collection.query(
            query_texts=[database_query_prepend + query],
            n_results=n_results,
            where=metadata_condition
        )
        print("ChromaDB query complete")
        return results.get('documents')[0]
    
    def getContext(self, query, ticker_long_name):
        """
        Retrieves contextual information relevant to a user query using a hybrid of postgreSQL and ChromaDB retrieval.

        Attempts to generate and execute an SQL query to obtain structured financial data 3 times (non zero temperature of text to sql model). 
        If query execution fails or yields no results, falls back to ChromaDB vector search using multiple metadata filters.

        Args:
            query (str): User's input question or instruction.
            ticker_long_name (str): The full name of the ticker to prepend to the query for domain-specific retrieval.

        Returns:
            str: A compiled context string composed of structured SQL data and/or relevant document snippets from ChromaDB.
        """   

        RAG_context= []

        use_ChromaDB = True

        # Set number of attempts for text to sql to generated a useful query
        MAX_ATTEMPTS = 3
        attempt = 0
        success = False

        # Ensure market outlook query utilises chromaDB for more useful results on homepage
        if query != "What is the current outlook of the market based on recent news?":
            while attempt < MAX_ATTEMPTS and not success:
                attempt += 1
                print(f"Attempt {attempt}: Generating and executing SQL query...", flush=True)

                # Get SQL Query and check if the output is not "No suitable query." Retry query generation if MAX_ATTEMPTS not reached.
                sql_query = self.getSQLQuery(query) 
                if re.fullmatch(r"\s*No suitable query\.\s*", sql_query):
                    break

                sql_query = clean_sql_query(sql_query)

                # Interface retrieved query with postgreSQL database.
                try:
                    conn = get_db_connection(STOCK_DB_CONFIG)
                    cursor = conn.cursor()
                    print(sql_query, flush=True)
                    cursor.execute(sql_query)
                    sql_results = cursor.fetchall()
                    column_names = [desc[0] for desc in cursor.description]
                    cursor.close()
                    conn.close()

                    if sql_results:
                        formatted_rows = [
                            ", ".join(f"{col}: {val}" for col, val in zip(column_names, row))
                            for row in sql_results
                        ]
                        sql_context = "\n".join(formatted_rows)
                        sql_context = sql_context + "The above are the values relevant to the SQL query"
                        RAG_context.append(sql_context)
                        # Valid context retrieved to be used for chatbot
                        use_ChromaDB = False
                        success = True
                    else:
                        # Query returned empty results. Use ChromaDB as fallback.
                        print("Query returned no results.", flush=True)
                        RAG_context.append("Query returned no results.")
                        success = True

                except Exception as e:
                    # Query throws error when executed.
                    # Retry query generation if MAX_ATTEMPTS not reached.
                    print(f"SQL Execution Error: {e}", flush=True)
                    RAG_context.append(f"SQL query failed on attempt {attempt}: {str(e)}")
                    use_ChromaDB = True
                    success = False
        
        if use_ChromaDB:
            # retrieves 2 sources from financial reports
            RAG_context.extend(self.processInput(query, ticker_long_name, 2, {"title": {"$eq": "tenk"}}))


            # retrieves 3 sources from news sources that were published in the past 2 days
            current_time = datetime.now()
            two_days_ago = current_time - timedelta(days=2)
            unix_timestamp_two_days_ago = int(two_days_ago.timestamp())
            RAG_context.extend(self.processInput(query, ticker_long_name, 3, {
                "$and": [
                    {"title": {"$ne": "tenk"}},
                    {"has_publish_date": True},
                    {"publish_date": {"$gt": unix_timestamp_two_days_ago}}
                ]
            }))

            # retrieves 1 source from news sources that were published from more than 2 days ago
            RAG_context.extend(self.processInput(query, ticker_long_name, 1, {
                "$and": [
                    {"title": {"$ne": "tenk"}},
                    {"has_publish_date": True},
                    {"publish_date": {"$lt": unix_timestamp_two_days_ago}}
                ]
            }))


            # retrieves 2 sources from ticker information that was retrieved from yahoo finance
            RAG_context.extend(self.processInput(query, ticker_long_name, 2, {
                "$and": [
                    {"title": {"$ne": "tenk"}},
                    {"has_publish_date": False}
                ]
            }))

        context = "\n\n--- End of Item ---\n\n".join(RAG_context)
        return context
    
    def getOutput(self, query, ticker_id, ticker_long_name):
        """
        Generates a response to the user query using a retrieval-augmented generation (RAG) pipeline.

        Gets the relevant context and provides it and the query to a HuggingFace LLM (LLama 3.3-70B Instruct) for inference.

        Args:
            query (str): The user's question or request.
            ticker_id (str): The ticker symbol ID of the company referenced in the query.
            ticker_long_name (str): The full name of the ticker.

        Returns:
            str: The LLM-generated response based on retrieved context and the original query.
        """
        context = self.getContext(query, ticker_long_name)
        print(context, flush=True)
        
        self.messages = [
            {
                "role": "system",
                "content": prompt
            },
            {
                "role": "user",
                "content": f"""Context:\n{context}
                                
                               Question: {query}

                               Response:
                            """
            }
        ]

        print("Sent request")

        completion = client.chat.completions.create(
                        model="meta-llama/Llama-3.3-70B-Instruct",
                        messages=self.messages,
                        max_tokens=2000,
                        temperature = 0
                    )
        print(completion, flush=True)
        llm_output = completion.choices[0].message['content']
        print(llm_output)
        return llm_output
