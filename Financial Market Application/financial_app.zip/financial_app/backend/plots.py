import plotly.graph_objects as go
from plotly.subplots import make_subplots
from pull_data import query_historical_prices
from ta.trend import MACD 
from ta.momentum import StochasticOscillator 

def get_price(ticker):
    """
    This function queries the historical price data for the given ticker and returns
    a dictionary containing the dates, opening prices, highest prices, lowest prices,
    closing prices, and volume data in list format. It also returns the raw DataFrame.

    :param str ticker: The ticker ID for which the historical price data is to be retrieved.
    :return: A dictionary containing lists of historical data and the raw DataFrame.
    :rtype: dict
    """
    df = query_historical_prices(ticker)
    return {
        'dates': df['date'].tolist(),
        'opens': df['open'].tolist(),
        'highs': df['high'].tolist(),
        'lows': df['low'].tolist(),
        'closes': df['close'].tolist(),
        'volume': df['volume'].tolist(),
        'df': df
    }

def calculate_indicators(df):
    """
    This function calculates moving averages (with windows ranging from 5 to 50),
    MACD (Moving Average Convergence Divergence), and Stochastic Oscillator for the
    historical price data in the DataFrame. The results are added as new columns to
    the DataFrame.

    :param pd.DataFrame df: A DataFrame containing historical price data with columns 'close', 'high', and 'low'.
    :return: The original DataFrame with added columns for moving averages, MACD, and Stochastic Oscillator values,
             along with the calculated MACD and Stochastic Oscillator values.
    :rtype: tuple (pd.DataFrame, MACD, StochasticOscillator)
    """
    # Moving Averages
    for window in range(5, 55, 5):
        df[f'MA{window}'] = df['close'].rolling(window=window).mean()

    # MACD
    macd = MACD(close=df['close'], window_slow=26, window_fast=12, window_sign=9)
    # Stochastic
    stochastic = StochasticOscillator(high=df['high'], low=df['low'], close=df['close'], window=14, smooth_window=3)
    return df, macd, stochastic

def create_subplots(ticker):
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.1, row_heights=[0.8, 0.2])
    return fig

def create_price_charts(fig, dates, opens, highs, lows, closes, df):
    fig.add_trace(go.Candlestick(x=dates, open=opens, high=highs, low=lows, close=closes, name='Candlestick', visible=True), row=1, col=1)
    fig.add_trace(go.Scatter(x=dates, y=closes, name='Line', line=dict(color='red'), fill='tozeroy', fillcolor='rgb(251, 180, 174)', visible=False,
                            hoverinfo='x+y', hovertemplate='Date: %{x|%d %b %Y}<br>Price: %{y:.2f}'), row=1, col=1)

def add_technical_indicators(fig, dates, df, macd, stochastic):
    """
    Add technical indicators (MA, volume, MACD, and Stochastic) to a Plotly figure.

    Adds moving averages (5-50), volume, MACD (histogram, line, signal), and
    Stochastic Oscillator (%K and %D) to the figure in appropriate subplots.

    :param fig: The Plotly figure.
    :param dates: List of dates corresponding to price data.
    :param df: DataFrame with price and indicator data.
    :param macd: MACD object with MACD data.
    :param stochastic: Stochastic Oscillator object with %K and %D data.
    :return: Updated Plotly figure.
    """
    for window in range(5, 55, 5):
        fig.add_trace(go.Scatter(
            x=dates, y=df[f'MA{window}'],
            opacity=0.6,
            line=dict(width=2),
            name=f'MA {window}', visible=False
        ), row=1, col=1)

    fig.add_trace(go.Bar(x=dates, y=df['volume'], name='Volume', visible=False, marker=dict(color='#000000')), row=2, col=1)
    fig.add_trace(go.Bar(x=dates, y=macd.macd_diff(), name='MACD Histogram', visible=False), row=2, col=1)
    fig.add_trace(go.Scatter(x=dates, y=macd.macd(), line=dict(color='black', width=2), name='MACD', visible=False), row=2, col=1)
    fig.add_trace(go.Scatter(x=dates, y=macd.macd_signal(), line=dict(color='blue', width=1), name='Signal', visible=False), row=2, col=1)
    fig.add_trace(go.Scatter(x=dates, y=stochastic.stoch(), line=dict(color='black', width=1), name='%K', visible=False), row=2, col=1)
    fig.add_trace(go.Scatter(x=dates, y=stochastic.stoch_signal(), line=dict(color='blue', width=1), name='%D', visible=False), row=2, col=1)

def update_figure_layout(fig, ticker, xaxis_range=None):
    """
    Update the layout of the Plotly figure for a stock ticker, including hover mode, menus, title, and axis settings.

    Allows switching between candlestick/line charts, technical indicators, moving averages, volumes, MACD, and Stochastic indicators.

    :param fig: The Plotly figure to update.
    :param ticker: Stock ticker symbol for the title.
    :param xaxis_range: Optional x-axis range; defaults to the current range if None.
    """
    ma_visibility_base = [True, False]  # candlestick visible, line hidden

    if xaxis_range is None:
        xaxis_range = fig['layout']['xaxis'].range

    fig.update_layout(
        hovermode='x unified',
        updatemenus=[
            dict(
                buttons=[
                    dict(label="Candlestick", method="update", args=[
                        {"visible": [True, False] + [False]*16},
                        {"sliders": []}
                    ]),
                    dict(label="Line", method="update", args=[
                        {"visible": [False, True] + [False]*16},
                        {"sliders": []}
                    ])
                ],
                direction="down", showactive=True, x=0.87, y=1.05,
                font=dict(family="Helvetica", size=12, color="black")),
            dict(
                buttons=[
                    dict(label="Technical Indicators", method="update", args=[
                        {"visible": [True, False] + [False]*16},
                        {"sliders": []}
                    ]),
                    dict(label="Moving Averages", method="update", args=[
                        {"visible": ma_visibility_base + [True] + [False]*9 + [False]*6},
                        {"sliders": [{
                            "active": 0,
                            "xanchor": "center", "yanchor": "top",
                            "x": 0.5, "y": -0.1,
                            "len": 0.6,
                            "pad": {"b": 10},
                            "currentvalue": {"prefix": "MA: ", "font": {"size": 12}},
                            "steps": [
                                {
                                    "label": f"MA {window}",
                                    "method": "update",
                                    "args": [{"visible": ma_visibility_base + [
                                        i == idx for i in range(10)
                                    ] + [False]*6}]
                                }
                                for idx, window in enumerate(range(5, 55, 5))
                            ]
                        }]}
                    ]),
                    dict(label="Volumes", method="update", args=[
                        {"visible": [True, False] + [False]*10 + [True] + [False]*5},
                        {"sliders": []}
                    ]),
                    dict(label="MACD", method="update", args=[
                        {"visible": [True, False] + [False]*11 + [True, True, True] + [False, False]},
                        {"sliders": []}
                    ]),
                    dict(label="Stochastic", method="update", args=[
                        {"visible": [True, False] + [False]*13 + [True, True]},
                        {"sliders": []}
                    ])
                ],
                direction="down", showactive=True, x=0.5, y=0.92,
                font=dict(family="Helvetica", size=12, color="black"), visible=True)
        ],
        title=dict(text=f"{ticker} Performance", x=0.5, y=0.92, font=dict(weight='bold')),
        template="plotly_white",
        xaxis=dict(
        range=xaxis_range,
        rangebreaks=[
            # Don't include weekends
            dict(bounds=["sat", "mon"]),

            dict(values=[
                "2024-01-01",
                "2024-12-25",
                "2024-12-26",
                "2024-11-28",
            ])
        ]
    )
    )

def set_x_axis(fig):
    """
    Configure the x-axis for a Plotly figure, including title, date formatting, and range selectors.

    :param fig: The Plotly figure to update.
    """
    fig.update_xaxes(
        rangeslider_visible=False,
        title=dict(text="Year"),
        title_font=dict(family="Helvetica", size=14),
        row=2,
        col=1
    )
    fig.update_xaxes(
        tickformat="%Y", 
        type="date",  
        row=2, col=1
    )
    fig.update_xaxes(
        rangeslider_visible=False,
        rangeselector=dict(
            buttons=list([
                dict(count=1, label="1M", step="month", stepmode="backward"),
                dict(count=3, label="3M", step="month", stepmode="backward"),
                dict(count=6, label="6M", step="month", stepmode="backward"),
                dict(count=1, label="1Y", step="year", stepmode="backward"),
                dict(count=5, label="5Y", step="year", stepmode="backward"),
                dict(count=10, label="10Y", step="year", stepmode="backward"),
                dict(label="All", step="all")
            ])
        ), 
        row=1, col=1
    )

def set_y_axis(fig):
    """
    Configure the y-axis for a Plotly figure, including the title and font settings.

    :param fig: The Plotly figure to update.
    """
    fig.update_yaxes(title=dict(text="Price"), title_font=dict(family="Helvetica", size=14), row=1, col=1)

def create_candlestick_chart(ticker):
    """
    Create a candlestick chart for a given ticker, including price data and technical indicators.

    :param ticker: The stock ticker for which the chart is generated.
    :return: A Plotly figure containing the candlestick chart and indicators.
    """
    price_data = get_price(ticker)
    df, macd, stochastic = calculate_indicators(price_data['df'])
    fig = create_subplots(ticker)
    create_price_charts(fig, price_data['dates'], price_data['opens'], price_data['highs'], price_data['lows'], price_data['closes'], df)
    add_technical_indicators(fig, price_data['dates'], df, macd, stochastic)

    xaxis_range = fig.layout.xaxis.range
    update_figure_layout(fig, ticker, xaxis_range)
    set_x_axis(fig)
    set_y_axis(fig)
    fig.update_yaxes(type="linear")
    return fig
