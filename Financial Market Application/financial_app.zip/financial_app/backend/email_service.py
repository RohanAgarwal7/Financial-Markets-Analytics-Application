import asyncio
import os
import ssl
import certifi
import logging
from email.message import EmailMessage
import aiosmtplib
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def send_mail(to_email: str, subject: str, body: str):
    """
    Send an email asynchronously using SMTP.

    :param str to_email: The recipient's email address.
    :param str subject: The subject of the email.
    :param str body: The body content of the email.
    :return: None
    :raises Exception: If sending the email fails.
    """
    smtp_hostname = os.getenv('EMAIL_HOST', 'smtp.gmail.com')
    smtp_port = int(os.getenv('EMAIL_PORT', 587))
    smtp_username = os.getenv('EMAIL_USER')
    smtp_password = os.getenv('EMAIL_PASS')
    from_email = os.getenv('EMAIL_USER')
    message = EmailMessage()
    message["From"] = from_email
    message["To"] = to_email
    message["Subject"] = subject
    message.set_content(body)
    context = ssl.create_default_context(cafile=certifi.where())
    
    try:
        await aiosmtplib.send(
            message,
            hostname=smtp_hostname,
            port=smtp_port,
            username=smtp_username,
            password=smtp_password,
            start_tls=True,
            tls_context=context,
        )
        logger.info(f"Email sent to {to_email}")
    except Exception as e:
        logger.error(f"Failed to send email to {to_email}: {str(e)}")
        raise

def send_verification_email(email: str, verification_url: str):
    """
    Send a verification email to the specified email address.

    :param str email: The recipient's email address.
    :param str verification_url: The URL to be included in the email for verification.
    :return: None
    :raises Exception: If sending the verification email fails.
    """

    subject = "Verify Your Email"
    body = f"Please click this link to verify your email: {verification_url}"
    try:
        asyncio.run(send_mail(email, subject, body))
        logger.info(f"Verification email sent to {email}")
    except Exception as e:
        logger.error(f"Failed to send verification email to {email}: {str(e)}")
        raise
