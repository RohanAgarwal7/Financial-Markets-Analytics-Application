// App.js - Defines public and protected routes, handles layout and authentication state.

import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Welcome from './components/Welcome/Welcome';
import Login from './components/Login/Login';
import Signup from './components/Signup/Signup';
import ForgotPassword from './components/ForgotPassword/ForgotPassword';
import Layout from './components/Layout/Layout';
import Home from './components/Home/Home';
import CompanyList from './components/CompanyList/CompanyList';
import Company from './components/Company/Company';
import Watchlist from './components/Watchlist/Watchlist';
import ChatBox from './components/ChatBox/ChatBox'; 

function App() {
    const [results, setResults] = useState(null);
    const [jwtToken, setJwtToken] = useState(localStorage.getItem('token') || '');

    return (
        <>
            <Routes>
                {/* Public Routes */}
                <Route path="/" element={<Welcome />} />
                <Route path="/login" element={<Login setJwtToken={setJwtToken} />} />
                <Route path="/signup" element={<Signup />} />
                <Route path="/forgot-password" element={<ForgotPassword />} />

                {/* Protected/Main Routes inside Layout */}
                <Route element={<Layout setResults={setResults} jwtToken={jwtToken} setJwtToken={setJwtToken} />}> 
                    <Route path="/home" element={<Home />} />       
                    <Route path="/companies" element={<CompanyList />} />
                    <Route path="/companies/:ticker" element={<Company results={results} setResults={setResults} jwtToken={jwtToken} />} />
                    <Route path="/watchlist" element={<Watchlist jwtToken={jwtToken} />} />
                </Route>
            </Routes>
            {/* Add ChatBox below the Routes to display on every page */}
            <ChatBox />
        </>
    );
}

export default function Root() {
    return (
        <Router>
            <App />
        </Router>
    );
}
