/**
 * Watchlist Component
 * 
 * This component allows authenticated users to manage a personal stock watchlist.
 * Users can view their current watchlist which is fetched from the backend, 
 * add new ticker symbols to their watchlist, remove existing ticker from their 
 * watchlist and click on a ticker  to view detailed information about that company.
 * 
 * This requires a valid JWT access token stored in localStorage. Otherwise 
 * it redirects to login if the token is missing or expired (401 Unauthorized).
 *
 * @component
 * @returns {JSX.Element} A responsive watchlist page for managing a user's personal stock tickers.
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './watchlist.css';

function Watchlist() {
    const [watchlist, setWatchlist] = useState([]);
    const [ticker, setTicker] = useState('');
    const [message, setMessage] = useState(''); 
    const navigate = useNavigate();

    /**
     * Fetches the user's watchlist from the backend.
     * If the user is not authenticated, redirects to the login page.
     */
    const fetchWatchlist = useCallback(async () => {
        const accessToken = localStorage.getItem('accessToken');
        if (!accessToken) {
            navigate('/login');
            return;
        }

        try {
            const response = await fetch('http://127.0.0.1:5000/', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                },
            });
            if (!response.ok) {
                if (response.status === 401) {
                    navigate('/login');
                    return;
                }
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to fetch watchlist');
            }
            const data = await response.json();
            setWatchlist(data.stocks || []);
            setMessage(''); 
        } catch (error) {
            console.error('Error fetching watchlist:', error);
            setMessage(error.message || 'Failed to load watchlist.');
        }
    }, [navigate]);

    /**
     * Runs fetchWatchlist when the component mounts.
     */
    useEffect(() => {
        fetchWatchlist();
    }, [fetchWatchlist]);

    const addTicker = async (e) => {
        e.preventDefault();
        const accessToken = localStorage.getItem('accessToken');
        if (!accessToken) {
            navigate('/login');
            return;
        }

        if (!ticker) {
            setMessage('Please enter a ticker symbol.');
            setTicker(''); 
            return;
        }

        try {
            const response = await fetch('http://127.0.0.1:5000/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Authorization': `Bearer ${accessToken}`,
                },
                body: new URLSearchParams({ ticker }),
            });
            const data = await response.json();
            if (!response.ok) {
                if (response.status === 401) {
                    navigate('/login');
                    return;
                }
                setMessage(data.error || 'Failed to add ticker.');
                setTicker(''); 
                return;
            }
            setTicker(''); 
            setWatchlist(data.stocks || []);
            setMessage(''); 
        } catch (error) {
            console.error('Error adding ticker:', error);
            setMessage(error.message || 'Failed to add ticker.');
            setTicker(''); 
        }
    };

    const removeTicker = async (tickerToRemove) => {
        const accessToken = localStorage.getItem('accessToken');
        if (!accessToken) {
            navigate('/login');
            return;
        }

        try {
            const response = await fetch('http://127.0.0.1:5000/remove', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${accessToken}`,
                },
                body: JSON.stringify({ ticker: tickerToRemove }),
            });
            const data = await response.json();
            if (!response.ok) {
                if (response.status === 401) {
                    navigate('/login');
                    return;
                }
                throw new Error(data.error || 'Failed to remove ticker');
            }
            setWatchlist(data.stocks || []);
            setMessage(''); 
        } catch (error) {
            console.error('Error removing ticker:', error);
            setMessage(error.message || 'Failed to remove ticker.');
        }
    };

    return (
        <div className="watchlist-container">
            <h1 className="watchlist-title">Watchlist</h1>
            <div className="watchlist-input-container">
                <input
                    type="text"
                    value={ticker}
                    onChange={(e) => setTicker(e.target.value.toUpperCase())}
                    placeholder="Enter ticker (e.g., AGI.AX)"
                    className="watchlist-input"
                />
                <button onClick={addTicker} className="watchlist-add-button">
                    Add
                </button>
            </div>
            {message && <p className="watchlist-message">{message}</p>}
            {watchlist.length > 0 ? (
                <table className="watchlist-table">
                    <thead>
                        <tr>
                            <th>Ticker</th>
                            <th>Price</th>
                            <th>Change %</th>
                            <th>High</th>
                            <th>Low</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {watchlist.map((stock) => (
                                <tr key={stock.ticker}>
                                <td>
                                    <Link to={`/companies/${stock.ticker}`} className="watchlist-link">
                                        {stock.ticker}
                                    </Link>
                                </td>
                                <td>{stock.price}</td>
                                <td>{stock.change_pct.toFixed(2)}%</td>
                                <td>{stock.high}</td>
                                <td>{stock.low}</td>
                                <td>
                                    <button
                                        onClick={() => removeTicker(stock.ticker)}
                                        className="watchlist-remove-button"
                                    >
                                        Remove
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <p className="watchlist-empty">Your watchlist is empty.</p>
            )}
        </div>
    );
}

export default Watchlist;