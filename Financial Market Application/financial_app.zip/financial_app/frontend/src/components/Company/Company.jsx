/**
 * Company Component
 * 
 * This component fetches and displays detailed financial data, stock prices, 
 * technical indicators, and an interactive stock chart for a selected company.
 * 
 * It automatically fetches data based on the ticker symbol from the URL.
 * 
 * @component
 * @returns {JSX.Element} A page showing the company's financial details and visualizations.
 */

import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Plot from 'react-plotly.js';
import './Company.css';


function Company() {
  const { ticker } = useParams();
  const [loading, setLoading] = useState(true);
  const [results, setResults] = useState(null);
  const [stockDetails, setStockDetails] = useState(null);
  const [financialRatios, setFinancialRatios] = useState(null);
  const [technicalIndicators, setTechnicalIndicators] = useState(null);

  /**
   * Fetch stock chart data and various stock information
   */
  useEffect(() => {
    const fetchChartData = async () => {
      try {
        const response = await fetch(`http://127.0.0.1:5000/visualise/${ticker}`);
        if (!response.ok) throw new Error('Failed to fetch chart data');
        const jsonData = await response.json();
        const parsedData = JSON.parse(jsonData);
        setResults(parsedData);
      } catch (error) {
        console.error('Error fetching chart data:', error);
        setResults(null);
      } finally {
        setLoading(false);
      }
    };


    const fetchDetails = async () => {
      try {
        const stockRes = await fetch(`http://127.0.0.1:5000/api/stock_details/${ticker}`);
        const stockData = await stockRes.json();
        console.log("Stock Details:", stockData);
        if (stockData.error) {
          console.warn("Stock details error:", stockData.error);
          setStockDetails(null);
        } else {
          setStockDetails({
            stock_price: stockData.regular_market_price,
            market_cap: stockData.market_cap,
            shares_outstanding: stockData.shares_outstanding,
            sentiment: stockData.sentiment,
            confidence: stockData.confidence
          });
        }


        const ratioRes = await fetch(`http://127.0.0.1:5000/api/financial_ratios/${ticker}`);
        const ratioData = await ratioRes.json();
        console.log("Financial Ratios:", ratioData);
        if (ratioData.error) {
          console.warn("Financial ratio error:", ratioData.error);
          setFinancialRatios(null);
        } else {
          setFinancialRatios(ratioData);
        }

        const technicalRes = await fetch(`http://127.0.0.1:5000/api/technical_indicators/${ticker}`);
        const technicalData = await technicalRes.json();
        console.log("Technical Indicators:", technicalData);
        if (technicalData.error) {
          console.warn("Technical indicator error:", technicalData.error);
          setTechnicalIndicators(null);
        } else {
          setTechnicalIndicators(technicalData);
        }


      } catch (error) {
        console.error('Error fetching details:', error);
        setStockDetails(null);
        setFinancialRatios(null);
        setTechnicalIndicators(null);
      }
    };

    fetchChartData();
    fetchDetails();
  }, [ticker]);

  /**
  * Helper to format numbers into US Dollar currency.
  * @param {number} num 
  * @returns {string}
  */
  const formatCurrency = (num) => {
    if (!num && num !== 0) return "N/A";
    return Number(num).toLocaleString('en-US', { style: 'currency', currency: 'USD' });
  };

  /**
  * Helper to safely format a number with 2 decimal places.
  * @param {number} val 
  * @returns {string}
  */
  const safeFixed = (val) => {
    const num = Number(val);
    return isFinite(num) ? num.toFixed(2) : "N/A";
  };

  /**
  * Return a CSS class based on sentiment (positive, negative, neutral).
  * @param {string} sentiment 
  * @returns {string}
  */
  const sentimentClass = (sentiment) => {
    if (sentiment === "positive") return "sentiment-positive";
    if (sentiment === "negative") return "sentiment-negative";
    return "sentiment-neutral"; // Default if sentiment is unknown
  };

  /**
   * Return a CSS class based on stock outlook (bullish, bearish, neutral).
   * @param {string} outlook 
   * @returns {string}
   */
  const outlookClass = (outlook) => {
    if (outlook === "Bullish") return "outlook-bullish";
    if (outlook === "Bearish") return "outlook-bearish";
    return "outlook-neutral"; // Default if outlook is unknown
  };



  if (loading) return <p className="text-center mt-10">Loading chart...</p>;
  if (!results) return <p className="text-center mt-10">No chart data available.</p>;


  return (
    <div className="company-container">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-8">
          {ticker.toUpperCase()} Stock Visualization
        </h2>

        {/* Graph and Technical Indicators Section */}
        <div className="graph-and-technical">
          <div className="company-graph">
            <Plot
              data={results.data}
              layout={{
                ...results.layout,
                autosize: true,
                margin: { t: 50, l: 50, r: 50, b: 50 },
                updatemenus: results.layout.updatemenus?.map(menu => ({
                  ...menu,
                  x: 0,
                  y: 1.2,
                  xanchor: 'left',
                  yanchor: 'top',
                })),
              }}
              style={{ width: '100%', height: '500px' }}
              config={{ responsive: true }}
            />
          </div>

          {technicalIndicators && (
            <div className="technical-table">
              <h3>Technical Indicators</h3>
              <table>
                <tbody>
                  <tr><td>SMA (20)</td><td>{technicalIndicators.SMA_20}</td></tr>
                  <tr><td>RSI (14)</td><td>{technicalIndicators.RSI_14}</td></tr>
                  <tr><td>MACD</td><td>{technicalIndicators.MACD}</td></tr>
                  <tr><td>MACD Signal</td><td>{technicalIndicators.MACD_signal}</td></tr>
                  {/* Add the Outlook row */}
                  <tr>
                    <td>Outlook</td>
                    <td className={outlookClass(Number(technicalIndicators.MACD) > Number(technicalIndicators.MACD_signal) ? "Bullish" : "Bearish")}>
                      {Number(technicalIndicators.MACD) > Number(technicalIndicators.MACD_signal) ? "Bullish" : "Bearish"}
                    </td>
                  </tr>
                  <tr>
                    <td>RSI Reading</td>
                    <td>{Number(technicalIndicators.RSI_14) > 70 ? "Overbought" : Number(technicalIndicators.RSI_14) < 30 ? "Oversold" : "Neutral"}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Other Tables Section */}
        <div className="company-tables">
          {stockDetails && (
            <div className="company-table">
              <h3>Share Information</h3>
              <table>
                <tbody>
                  <tr><td>Stock Price</td><td>{formatCurrency(stockDetails.stock_price)}</td></tr>
                  <tr><td>Market Cap</td><td>{formatCurrency(stockDetails.market_cap)}</td></tr>
                  <tr><td>Shares Outstanding</td><td>{stockDetails.shares_outstanding?.toLocaleString() || "N/A"}</td></tr>
                  <tr><td>Sentiment</td><td className={sentimentClass(stockDetails.sentiment)}>{stockDetails.sentiment || "N/A"}</td></tr>
                  <tr><td>Confidence</td><td>{safeFixed(stockDetails.confidence)}</td></tr>
                </tbody>
              </table>
            </div>
          )}

          {financialRatios && (
            <div className="company-table">
              <h3>Key Fundamentals</h3>
              <table>
                <tbody>
                  <tr><td>Current Ratio</td><td>{safeFixed(financialRatios.current_ratio)}</td></tr>
                  <tr><td>Cash Ratio</td><td>{safeFixed(financialRatios.cash_ratio)}</td></tr>
                  <tr><td>Debt Ratio</td><td>{safeFixed(financialRatios.debt_ratio)}</td></tr>
                  <tr><td>Debt-to-Equity</td><td>{safeFixed(financialRatios.debt_to_equity)}</td></tr>
                  <tr><td>Return on Assets</td><td>{safeFixed(financialRatios.return_on_assets)}</td></tr>
                  <tr><td>Return on Equity</td><td>{safeFixed(financialRatios.return_on_equity)}</td></tr>
                  <tr><td>Basic EPS</td><td>{safeFixed(financialRatios.basic_eps)}</td></tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );


}


export default Company;