/**
 * SearchBar Component
 * 
 * A dynamic search input that allows users to search for company tickers by ID or name.
 * As users type, it fetches ticker data and shows a live dropdown with matching results.
 * Users can either select a suggestion or manually submit the input to navigate
 * to the corresponding company page.
 * 
 * @component
 * @returns {JSX.Element} A search input with real-time suggestions and navigation.
 */

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaSearch } from 'react-icons/fa';
import axios from 'axios';
import './SearchBar.css';

export const SearchBar = () => {
  const [input, setInput] = useState('');
  const [tickers, setTickers] = useState([]);
  const [filteredTickers, setFilteredTickers] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    axios.get('http://localhost:5000/api/tickers')
      .then(response => setTickers(response.data))
      .catch(err => console.error('Error fetching tickers:', err));
  }, []);

  useEffect(() => {
    const search = input.trim().toUpperCase();
    if (search === '') {
      setFilteredTickers([]);
      setShowDropdown(false);
    } else {
      const filtered = tickers.filter(t =>
        (t.ticker_id && t.ticker_id.toUpperCase().includes(search)) ||
        (t.long_name && t.long_name.toUpperCase().includes(search))
      );
      setFilteredTickers(filtered);
      setShowDropdown(true);
    }
  }, [input, tickers]);

  const handleSubmit = () => {
    const trimmed = input.trim().toUpperCase();
    if (trimmed) {
      navigate(`/companies/${trimmed}`);
      setShowDropdown(false);
    }
  };

  const handleDropdownClick = (tickerId) => {
    setShowDropdown(false);
    setInput('');
    navigate(`/companies/${tickerId}`);
  };

  return (
    <div className="search-container">
      <input
        className="search-input"
        type="text"
        placeholder="Enter Ticker here..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onFocus={() => input && setShowDropdown(true)}
      />
      <button className="search-btn" onClick={handleSubmit}>
        <FaSearch />
      </button>
      {showDropdown && filteredTickers.length > 0 && (
        <ul className="dropdown">
          {filteredTickers.map((ticker, index) => (
            <li key={index} onClick={() => handleDropdownClick(ticker.ticker_id)}>
              <strong>{ticker.ticker_id}</strong> - {ticker.long_name}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SearchBar;