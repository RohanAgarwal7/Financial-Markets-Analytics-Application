/**
 * Welcome Component
 * 
 * This component serves as the landing page for the financial analytics app.
 * It introduces the app's AI-powered features, displays the logo and tagline,
 * and provides a call-to-action button to navigate users to the login page.
 * 
 * @component
 * @returns {JSX.Element} A welcoming landing page with branding and login navigation.
 */

import React from 'react';
import { Link } from 'react-router-dom';
import './Welcome.css';
import Logo from '../../assets/Trading_Insights.png';

const Welcome = () => {
  return (
    <div className="welcome-container">
      <div className="hero">
        <img src={Logo} alt="Trading Insights Logo" className="logo-img large" />
        <h1 className="hero-title">AI-Powered Financial Market Analytics</h1>
        <p className="hero-subtext">
          Gain deep insights from real-time data, financial reports, and market sentiment.
          Powered by large language models and intelligent analysis.
        </p>
        <div className="cta-buttons">
          <Link to="/login" className="btn cta-btn">Login</Link>
        </div>
      </div>
    </div>
  );
};

export default Welcome;
