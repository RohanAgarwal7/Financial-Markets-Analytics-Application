/**
 * Signup Component
 * 
 * This component provides a user interface for creating a new account.
 * Users enter a username, email, and password to register.
 * It handles form validation, displays error messages, 
 * and navigates to the login page upon successful registration.
 * 
 * @component
 * @returns {JSX.Element} A responsive signup form layout with input fields and buttons.
 */

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Signup.css';
import UserIcon from '../../assets/User.jpg';
import EmailIcon from '../../assets/Email.png';
import PasswordIcon from '../../assets/Password.png';
import axios from 'axios';

const Signup = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSignup = async () => {
    if (!username || !email || !password) {
      setError('All fields are required.');
      return;
    }

    const userData = {
      username,
      email,
      password,
    };

    try {
      const response = await axios.post('http://127.0.0.1:5000/auth/register', userData);

      if (response.data.message === 'User registered successfully') {
        alert('Signup successful! A verification link has been sent to your email!')
        localStorage.setItem('username', username);
        navigate('/login');
      } else {
        setError('Unexpected response from server.');
      }
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.error || 'Failed to sign up. Please try again.');
    }
  };

  return (
    <div className="signup-container">
      <div className="signup-card">
        <h2 className="signup-header">SIGN UP</h2>
        {error && <p className="error-message">{error}</p>}
        <div className="input-group">
          <img src={UserIcon} alt="user icon" className="icon" />
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Username"
            className="input-field"
          />
        </div>
        <div className="input-group">
          <img src={EmailIcon} alt="email icon" className="icon" />
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            className="input-field"
          />
        </div>
        <div className="input-group">
          <img src={PasswordIcon} alt="password icon" className="icon" />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="input-field"
          />
        </div>

        <button className="signup-button" onClick={handleSignup}>
          SIGN UP
        </button>

        <p className="login-link">
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </div>
    </div>
  );
};

export default Signup;