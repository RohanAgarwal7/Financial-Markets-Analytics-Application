/**
 * Login Component
 * 
 * This component provides a user interface for logging into our finance app.
 * Users can enter their username or email and password to authenticate.
 * It handles form validation, displays error messages, and navigates 
 * to the homepage upon successful login.
 * 
 * @component
 * @returns {JSX.Element} A responsive login form layout with input fields and buttons.
 */

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Login.css';
import EmailIcon from '../../assets/Email.png';
import PasswordIcon from '../../assets/Password.png';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    if (!email || !password) {
      setError('Fill in all fields.');
      return;
    }

    try {
      const response = await fetch('http://127.0.0.1:5000/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username: email, password }),
      });

      const data = await response.json();

      if (response.ok) {
        console.log('Login successful:', data.message);
        localStorage.setItem('accessToken', data.tokens.access);
        localStorage.setItem('refreshToken', data.tokens.refresh);
        navigate('/home');
      } else {
        setError(data.error || 'Login failed.');
      }
    } catch (error) {
      setError('Something went wrong, please try again.');
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h2 className="login-header">LOGIN</h2>
        {error && <p className="error-message">{error}</p>}
        <div className="input-group">
          <img src={EmailIcon} alt="email icon" className="icon" />
          <input
            type="text" 
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Username or Email"
            className="input-field"
          />
        </div>
        <div className="input-group">
          <img src={PasswordIcon} alt="password icon" className="icon" />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="input-field"
          />
        </div>

        <button className="login-button" onClick={handleLogin}>
          LOGIN
        </button>

        <p className="signup-link">
          Don't have an account? <Link to="/signup">Sign up</Link>
        </p>
      </div>
    </div>
  );
};

export default Login;