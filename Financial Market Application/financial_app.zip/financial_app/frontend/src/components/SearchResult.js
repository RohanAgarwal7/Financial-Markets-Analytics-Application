import React from 'react'

export const SearchResult = ({result}) => {
    return (
        <div>{result.name}</div>
    )
}