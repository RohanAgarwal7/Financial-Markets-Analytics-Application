/**
 * HomePage Component
 * 
 * This component displays an interactive market overview dashboard.
 * Users can select between major stock markets (ASX 200, NYSE, NASDAQ),
 * view real-time market charts, read generated market trend analysis,
 * and browse macroeconomic news headlines.
 * 
 * @component
 * @returns {JSX.Element} A responsive homepage layout with charts, trends, and news sections.
 */

import React, { useEffect, useState } from 'react';
import Plot from 'react-plotly.js';
import ReactMarkdown from 'react-markdown';
import './Home.css';

const MARKET_OPTIONS = {
  "^AXJO": "ASX 200",
  "^NYA": "NYSE",
  "^IXIC": "NASDAQ"
};

function HomePage() {
  const [selectedMarket, setSelectedMarket] = useState("^AXJO");
  const [chartData, setChartData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [marketTrends, setMarketTrends] = useState('');
  const [news, setNews] = useState([]);

  /**
   * Fetch chart data for the selected market.
   * Runs on component mount and whenever `selectedMarket` changes.
   * Sets loading state during fetch operation.
   */
  useEffect(() => {
    const fetchChartData = async () => {
      setLoading(true);
      try {
        const response = await fetch(`http://127.0.0.1:5000/visualise/${selectedMarket}`);
        const jsonData = await response.json();
        setChartData(JSON.parse(jsonData));
      } catch (err) {
        console.error('Chart fetch failed:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchChartData();
  }, [selectedMarket]);

  /**
   * Fetch current market trend analysis. 
   * It runs only once on component mount.
   */
  useEffect(() => {
    const fetchMarketTrends = async () => {
      try {
        const response = await fetch('http://127.0.0.1:5000/market-trends');
        const data = await response.json();
        setMarketTrends(data.response);
      } catch (err) {
        console.error('Market trends fetch failed:', err);
      }
    };

    fetchMarketTrends();
  }, []);

  /**
   * Fetch macroeconomic news headlines.
   * It runs only once on component mount.
   */
  useEffect(() => {
    const fetchNews = async () => {
      try {
        const response = await fetch('http://127.0.0.1:5000/macro-news');
        const data = await response.json();
        setNews(data);
      } catch (err) {
        console.error('News fetch failed:', err);
      }
    };

    fetchNews();
  }, []);

  return (
    <div className="home-container">
      <div className="market-toggle">
        {Object.entries(MARKET_OPTIONS).map(([ticker, name]) => (
          <button
            key={ticker}
            className={`toggle-btn ${selectedMarket === ticker ? 'active' : ''}`}
            onClick={() => setSelectedMarket(ticker)}
          >
            {name}
          </button>
        ))}
      </div>

      <h2 className="market-heading">{MARKET_OPTIONS[selectedMarket]} Market Overview</h2>

      <div className="section-row">
        <div className="market-graph">
          {loading ? (
            <p>Loading chart...</p>
          ) : chartData ? (
            <Plot
              data={chartData.data}
              layout={{
                ...chartData.layout,
                autosize: true,
                title: `${MARKET_OPTIONS[selectedMarket]} Market Chart`,
                paper_bgcolor: 'white',
                plot_bgcolor: 'white',
                font: { color: 'black' },
                margin: { t: 50, l: 50, r: 50, b: 50 },
                updatemenus: chartData.layout.updatemenus?.map(menu => ({
                  ...menu,
                  x: 0,
                  y: 1.2,
                  xanchor: 'left',
                  yanchor: 'top',
                })),
              }}
              config={{ responsive: true }}
              style={{ width: '100%', height: '500px' }}
            />
          ) : (
            <p>No chart data available.</p>
          )}
        </div>

        <div className="market-trends">
          {/* <h3>Current Market Trends</h3> */}
          <div>
            {marketTrends ? (
              <ReactMarkdown>{marketTrends}</ReactMarkdown> 
            ) : (
              'Loading trend analysis...'
            )}
          </div>
        </div>
      </div>

      <div className="news-section">
        <h3>Macro/Major News</h3>
        <div className="news-cards">
          {news.length === 0 ? (
            <p>Loading news...</p>
          ) : (
            news.map((item, index) => (
              <div className="news-card" key={index}>
                <a href={item.url} target="_blank" rel="noopener noreferrer">
                  {item.title}
                </a>
                <p>Published: {new Date(item.published).toLocaleDateString()}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default HomePage;
