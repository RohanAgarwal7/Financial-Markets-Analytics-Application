/**
 * CompanyList Component
 * 
 * This component displays a list of companies (tickers) fetched from the backend,
 * with filtering, sorting, and navigation to company detail pages.
 * 
 * Users can:
 * - Filter companies by market cap, industry, and sentiment.
 * - Sort companies by ticker, name, or market cap (ascending/descending).
 * - Click on a company to navigate to its detail page.
 *
 * @component
 * @returns {JSX.Element} A company list interface with filters and sort options.
 */

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './CompanyList.css';

function CompanyList({ setResults }) {
  const [tickers, setTickers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    marketCap: '',
    industry: '',
    sentiment: '',
  });
  const [industryOptions, setIndustryOptions] = useState([]);
  const [sort, setSort] = useState({ field: 'ticker_id', order: 'asc' });
  const navigate = useNavigate();

  /**
   * Fetch tickers based on filters and sort state.
   * Runs on component mount and whenever filters/sort change.
   */
  useEffect(() => {
    const fetchTickers = async () => {
      try {
        setLoading(true);
        setError(null);
        const params = {
          ...filters,
          sortField: sort.field,
          sortOrder: sort.order,
        };
        const response = await axios.get('http://localhost:5000/api/tickers', { params });
        setTickers(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching tickers:', error);
        setError('Failed to load companies. Please try again later.');
        setLoading(false);
      }
    };
    fetchTickers();
  }, [filters, sort]);

  /**
   * Fetch the list of industries for the industry filter dropdown.
   * Runs only once on component mount.
   */
  useEffect(() => {
    const fetchIndustries = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/industries');
        setIndustryOptions(res.data);
      } catch (error) {
        console.error("Failed to load industry list", error);
      }
    };
    fetchIndustries();
  }, []);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const handleSortChange = (field, order) => {
    setSort({ field, order });
  };

  const handleClick = (tickerId) => {
    navigate(`/companies/${tickerId}`);
  };
  
  /**
   * Format market cap numbers into human-readable strings (e.g., 1M, 1B).
   * 
   * @param {number} marketCap - Market capitalization value.
   * @returns {string} Formatted market cap string.
   */
  const formatMarketCap = (marketCap) => {
    if (!marketCap || marketCap <= 0) return 'N/A';

    let value = marketCap;
    let suffix = '';

    if (marketCap >= 1_000_000_000) {
      value = marketCap / 1_000_000_000;
      suffix = 'B';
    } else if (marketCap >= 1_000_000) {
      value = marketCap / 1_000_000;
      suffix = 'M';
    } else if (marketCap >= 1_000) {
      value = marketCap / 1_000;
      suffix = 'K';
    } else {
      return marketCap.toFixed(2);
    }

    return `${value.toFixed(2)}${suffix}`;
  };

  return (
    <div className="company-list-wrapper">
      <div className="sidebar">
        <div className="filter-container">
          <h3>Filters</h3>
          <div className="filter-group">
            <label>Market Cap</label>
            <select name="marketCap" onChange={handleFilterChange} value={filters.marketCap}>
              <option value="">All</option>
              <option value="small">Small (&lt; &#36;2B)</option>
              <option value="mid">Mid (&#36;2B - &#36;10B)</option>
              <option value="large">Large (&gt; &#36;10B)</option>
            </select>
          </div>
          <div className="filter-group">
            <label>Industry</label>
            <select name="industry" onChange={handleFilterChange} value={filters.industry}>
              <option value="">All</option>
              {industryOptions.map((industry, index) => (
                <option key={index} value={industry}>
                  {industry}
                </option>
              ))}
            </select>
          </div>
          <div className="filter-group">
            <label>Sentiment</label>
            <select name="sentiment" onChange={handleFilterChange} value={filters.sentiment}>
              <option value="">All</option>
              <option value="positive">Positive</option>
              <option value="neutral">Neutral</option>
              <option value="negative">Negative</option>
            </select>
          </div>
        </div>
      </div>
      <div className="company-list-container">
        <div className="company-list-header">
          <div className="header-column">
            <span>Ticker</span>
            <div className="sort-buttons">
              <button onClick={() => handleSortChange('ticker_id', 'asc')}>↑</button>
              <button onClick={() => handleSortChange('ticker_id', 'desc')}>↓</button>
            </div>
          </div>
          <div className="header-column">
            <span>Name</span>
            <div className="sort-buttons">
              <button onClick={() => handleSortChange('long_name', 'asc')}>↑</button>
              <button onClick={() => handleSortChange('long_name', 'desc')}>↓</button>
            </div>
          </div>
          <div className="header-column">
            <span>Market Cap</span>
            <div className="sort-buttons">
              <button onClick={() => handleSortChange('market_cap', 'asc')}>↑</button>
              <button onClick={() => handleSortChange('market_cap', 'desc')}>↓</button>
            </div>
          </div>
          <div className="header-column">
            <span>Industry</span>
          </div>
          <div className="header-column">
            <span>Sentiment</span>
          </div>
        </div>
        {loading ? (
          <p>Loading...</p>
        ) : error ? (
          <p className="error">{error}</p>
        ) : tickers.length === 0 ? (
          <p className="error">No companies found.</p>
        ) : (
          tickers.map((ticker, index) => (
            <div
              key={index}
              className="company-card"
              onClick={() => handleClick(ticker.ticker_id)}
            >
              <span className="ticker-id">{ticker.ticker_id}</span>
              <span className="ticker-name">{ticker.long_name}</span>
              <span className="market-cap">{formatMarketCap(ticker.market_cap)}</span>
              <span className="industry">{ticker.industry ?? 'N/A'}</span>
              <span className="sentiment">{ticker.sentiment ?? 'N/A'}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default CompanyList;
