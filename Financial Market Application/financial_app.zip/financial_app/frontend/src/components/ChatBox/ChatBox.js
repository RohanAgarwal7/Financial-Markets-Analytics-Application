/**
 * ChatBox Component
 * 
 * This component provides a resizable chat widget with message sending functionality.
 * Users can toggle the chatbox, type messages, and receive responses from the backend.
 * 
 * @component
 * @param {Array} messages - Initial messages passed to the chat box.
 * @param {Function} getMessage - Function to fetch messages externally (currently unused here).
 * @returns {JSX.Element} A floating chatbox component.
 */

import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import './ChatBox.css';
import ReactMarkdown from 'react-markdown';
import chatIcon from '../../assets/chat_icon.png';
import sendIcon from '../../assets/send_button.png';

export const ChatBox = ({ messages, getMessage }) => {
    const [chatOpen, setChatOpen] = useState(false);
    const [input, setInput] = useState("");
    const [chatMessages, setChatMessages] = useState([]);
    const msgEndRef = useRef(null);
    const chatBoxRef = useRef(null);
    const [dimensions, setDimensions] = useState({ width: 300, height: 510 });
    const resizeRef = useRef({ resizing: false, corner: null });

    /**
     * Toggle the visibility of the chat box.
     */
    const toggleChat = () => setChatOpen(!chatOpen);

    /**
     * Sends the user's input to the backend and updates the chat messages.
     */
    const handleSend = async () => {
        if (!input) return;

        const userMessage = { role: "user", content: input };
        setChatMessages(prev => [...prev, userMessage]);

        try {
            const res = await axios.post("http://127.0.0.1:5000/chat", {
                query: input,
            });

            const botResponse = { role: "bot", content: res.data.output };
            setChatMessages(prev => [...prev, botResponse]);
        } catch (error) {
            const errorMessage = { role: "bot", content: "Sorry, something went wrong. Please try again." };
            setChatMessages(prev => [...prev, errorMessage]);
        }

        setInput("");
    };

    /**
     * Scroll to the latest message whenever chatMessages change.
     */
    useEffect(() => {
        if (msgEndRef.current) {
            msgEndRef.current.scrollIntoView({ behavior: "smooth" });
        }
    }, [chatMessages]);

    /**
     * Handle resizing of the chat box when dragging corners.
     */
    useEffect(() => {
        const handleMouseMove = (e) => {
            if (!resizeRef.current.resizing) return;

            const box = chatBoxRef.current.getBoundingClientRect();
            let newWidth = dimensions.width;
            let newHeight = dimensions.height;

            if (resizeRef.current.corner === 'top-left') {
                newWidth = box.right - e.clientX;
                newHeight = box.bottom - e.clientY;
            } else if (resizeRef.current.corner === 'bottom-left') {
                newWidth = box.right - e.clientX;
                newHeight = e.clientY - box.top;
            }

            newWidth = Math.max(250, newWidth);
            newHeight = Math.max(300, newHeight);

            setDimensions({ width: newWidth, height: newHeight });
        };

        const handleMouseUp = () => {
            resizeRef.current = { resizing: false, corner: null };
        };

        window.addEventListener("mousemove", handleMouseMove);
        window.addEventListener("mouseup", handleMouseUp);

        return () => {
            window.removeEventListener("mousemove", handleMouseMove);
            window.removeEventListener("mouseup", handleMouseUp);
        };
    }, [dimensions]);

    /**
     * Start resizing the chat box from a given corner.
     * 
     * @param {string} corner - Corner name ('top-left' or 'bottom-left').
     */
    const startResize = (corner) => {
        resizeRef.current = { resizing: true, corner };
    };

    return (
        <>
            {chatOpen && <div className="chat-overlay" onClick={toggleChat}></div>}
            <div className="chatCon">
                <div
                    className="chat-box"
                    ref={chatBoxRef}
                    style={{
                        display: chatOpen ? 'block' : 'none',
                        width: dimensions.width,
                        height: dimensions.height,
                    }}
                >
                    <div className="resize-corner top-left" onMouseDown={() => startResize('top-left')} />
                    <div className="resize-corner bottom-left" onMouseDown={() => startResize('bottom-left')} />
                    <div className="header"> Chat With TradingInsights! </div>
                    <div className="msg-area">
                        {chatMessages.map((msg, i) => (
                            <div key={i} className={msg.role === "user" ? "right" : "left"}>
                                {msg.role === "bot" ? (
                                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                                ) : (
                                    <span>{msg.content}</span>
                                )}
                            </div>
                        ))}
                        <div ref={msgEndRef} />
                    </div>
                    <div className="footer">
                        <input
                            type="text"
                            placeholder="Type your question..."
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            className="message_input"
                            required
                        />
                        <button onClick={handleSend}>
                            <img src={sendIcon} alt="Send" />
                        </button>
                    </div>
                </div>
                <div className="pop">
                    <p>
                        <img src={chatIcon} onClick={toggleChat} alt="Chat Icon" />
                    </p>
                </div>
            </div>
        </>
    );
};

export default ChatBox;