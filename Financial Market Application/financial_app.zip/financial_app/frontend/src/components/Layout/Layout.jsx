import React from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import SearchBar from '../SearchBar/SearchBar';
import './Layout.css';
import Logo from '../../assets/Trading_Insights.png';

const Layout = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    navigate('/');
  };

  return (
    <div className="layout-container">
      {/* Top Navbar */}
      <header className="top-navbar">
        <div className="left-section">
          <img src={Logo} alt="Trading Insights Logo" className="logo-img" />
          <span className="welcome-text">Welcome, <span className="highlight">User</span></span>
        </div>
        <SearchBar />
        <div className="right-section">
          <button className="auth-button logout" onClick={handleLogout}>Logout</button>
        </div>
      </header>

      {/* Bottom Nav Tabs */}
      <nav className="tab-nav">
        <Link to="/home" className={`tab-link ${location.pathname.startsWith('/home') ? 'active' : ''}`}>Home</Link>
        <Link to="/companies" className={`tab-link ${location.pathname.startsWith('/companies') ? 'active' : ''}`}>Companies</Link>
        <Link to="/watchlist" className={`tab-link ${location.pathname === '/watchlist' ? 'active' : ''}`}>Watchlist</Link>
    </nav>


      <main className="content">
        <Outlet />
      </main>
    </div>
  );
};

export default Layout;
