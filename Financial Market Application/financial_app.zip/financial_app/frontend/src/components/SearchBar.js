import React, { useState } from 'react';
import { FaSearch } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

export const SearchBar = ({ setResults }) => {
    const [input, setInput] = useState('');
    const navigate = useNavigate();

    const fetchData = async (value) => {
        if (!value) {
            setResults(null);
            return;
        }

        try {
            const response = await fetch(`http://127.0.0.1:5000/visualise/${value}`);
            if (!response.ok) throw new Error('Failed to fetch chart data');

            const jsonData = await response.json();
            const parsedData = JSON.parse(jsonData); // Parse Flask's JSON string

            setResults(parsedData);
            navigate(`/companies/${value}`); // Navigate to /companies/{ticker}
        } catch (error) {
            console.error('Error fetching chart data:', error);
            setResults(null);
        }
    };

    const handleSearch = () => {
        fetchData(input);
    };

    return (
        <div className='input-wrapper'>
            <FaSearch id='search-icon' />
            <input
                placeholder='Enter Ticker here...'
                value={input}
                onChange={(e) => setInput(e.target.value)}
            />
            <button onClick={handleSearch}>Search</button>
        </div>
    );
};
