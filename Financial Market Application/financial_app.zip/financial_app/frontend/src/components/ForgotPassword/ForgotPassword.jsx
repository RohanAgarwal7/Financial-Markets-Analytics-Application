/**
 * ForgotPassword Component
 * 
 * This component renders a password reset form where users can request a password reset email
 * by entering their registered email address. It provides validation feedback and success/error messaging.
 * 
 * @component
 * @returns {JSX.Element} A password reset interface with email input.
 */
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './ForgotPassword.css';
import EmailIcon from '../../assets/Email.jpg';
import Logo from '../../assets/Trading_Insights.png';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleReset = () => {
    if (!email) {
      setError('Email is required.');
      return;
    }

    setSuccess(true);
    setError('');
  };

  return (
    <div className="forgot-password-container">
      <div className="forgot-password-card">
        <img src={Logo} alt="Logo" className="logo" />
        <h2 className="forgot-password-header">Forgot Password</h2>

        {!success ? (
          <>
            <div className="input-group">
              <img src={EmailIcon} alt="email icon" className="icon" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="input-field"
              />
            </div>
            {error && <p className="error-text">{error}</p>}
            <button className="reset-button" onClick={handleReset}>
              Send Reset Link
            </button>
          </>
        ) : (
          <p className="success-message">Reset link has been sent to your email!</p>
        )}

        <p className="back-to-login">
          <Link to="/login">← Go back to Login</Link>
        </p>
      </div>
    </div>
  );
};

export default ForgotPassword;
