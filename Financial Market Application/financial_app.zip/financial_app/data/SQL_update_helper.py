from transformers import AutoTokenizer, AutoModelForSequenceClassification
from newspaper import Article
import yfinance as yf
import pandas as pd
import torch

tokenizer = AutoTokenizer.from_pretrained("mrm8488/distilroberta-finetuned-financial-news-sentiment-analysis")
model = AutoModelForSequenceClassification.from_pretrained("mrm8488/distilroberta-finetuned-financial-news-sentiment-analysis")

ARTICLE_WEIGHT_HALF_LIFE = 7 * 24 # in terms of hours - equivalent to 7 days

def process_ticker_sentiment(ticker_id, conn):
    """
    Analyzes sentiment for a specific ticker based on its recent news articles and updates the database.

    Downloads and parses news articles for the given ticker, applies exponential decay weighting based 
    on article age, computes a weighted sentiment score using a pre-trained transformer model, and 
    updates the `ticker_sentiment` table with the dominant sentiment and confidence score.

    Args:
        ticker_id (str): The ID of the ticker to analyze.
        conn (psycopg2.connection): A connection object to the PostgreSQL database.

    Returns:
        None
    """

    cursor = conn.cursor()
    query = """
                SELECT 
                    ticker_id, 
                    title, 
                    url, 
                    published, 
                    EXTRACT(EPOCH FROM (NOW() - published))/3600 AS hours_old 
                FROM ticker_news 
                WHERE ticker_id = %s
            """
    cursor.execute(query, (ticker_id, ))
    news = cursor.fetchall()

    num_articles = 0
    texts = []
    weights = []
    for article in news:
        url = article[2]
        hours_old = article[4]

        news_article = Article(url)
        try:
            news_article.download()
            news_article.parse()
            if news_article.text: 
                texts.append(news_article.text)
                weights.append(0.5 ** (float(hours_old) / ARTICLE_WEIGHT_HALF_LIFE))
                num_articles += 1
        except Exception as e:
            continue

    if num_articles == 0:
        return None
    
    inputs = tokenizer(texts, return_tensors="pt", padding=True, truncation=True, max_length=512)
    
    with torch.no_grad():
        outputs = model(**inputs)
    
    probabilities = torch.softmax(outputs.logits, dim=1)
    
    weighted_sentiment = {
        "negative": 0.0,
        "neutral": 0.0,
        "positive": 0.0
    }

    total_weight = sum(weights)
    
    for i, weight in enumerate(weights):
        weighted_sentiment["negative"] += probabilities[i][0].item() * weight
        weighted_sentiment["neutral"] += probabilities[i][1].item() * weight
        weighted_sentiment["positive"] += probabilities[i][2].item() * weight
    
    weighted_sentiment = {
        k: v / total_weight 
        for k, v in weighted_sentiment.items()
    }
    
    sentiment = max(weighted_sentiment.items(), key=lambda item: item[1])

    insert_data_query = f"""
                INSERT INTO ticker_sentiment (ticker_id, sentiment, confidence, num_articles_analysed)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (ticker_id) 
                DO UPDATE SET 
                    sentiment = EXCLUDED.sentiment,
                    confidence = EXCLUDED.confidence,
                    num_articles_analysed = EXCLUDED.num_articles_analysed
            """
    
    cursor.execute(insert_data_query, (ticker_id, sentiment[0], sentiment[1], num_articles))
    conn.commit()
    print(f"Sentiment analysed for ticker {ticker_id}", flush=True)

def process_ticker_batch_sentiments(tickers, conn):
    """
    Processes sentiment analysis for a batch of tickers and updates the database accordingly.

    For each ticker in the input list, this function calls `process_ticker_sentiment` to analyze 
    recent news articles, compute sentiment scores, and insert or update results in the 
    `ticker_sentiment` table.

    Args:
        tickers (list of str): A list of ticker IDs to process.
        conn (psycopg2.connection): A connection object to the PostgreSQL database.

    Returns:
        None
    """
    for ticker in tickers:
        process_ticker_sentiment(ticker, conn)
        print(f"Processed {ticker} sentiment")

# This function is now unused due to intraday data no longer being  part of app requirements.
def update_intraday_data(tickers, conn, period="1d", interval="5m"):
    """
    Fetches and updates intraday stock price data for a list of tickers into the PostgreSQL database.

    This function uses Yahoo Finance to download intraday data at a given interval (default 5 minutes) 
    for the current trading day. The data is preprocessed and inserted into the `intraday_price_data` table.
    Duplicate entries based on (ticker_id, date, time) are ignored using ON CONFLICT DO NOTHING.

    Args:
        tickers (list of str): List of stock ticker symbols to fetch intraday data for.
        conn (psycopg2.connection): Active PostgreSQL database connection.
        period (str, optional): Period of data to fetch (e.g., '1d' for one day). Defaults to "1d".
        interval (str, optional): Data interval (e.g., '5m' for 5 minutes). Defaults to "5m".

    Returns:
        None
    """

    cursor = conn.cursor()
    data = yf.download(tickers, period="1d", interval="5m", prepost=True)
    data = data[['Close', 'High', 'Low', 'Open', 'Volume']].copy()
    data = data.stack(future_stack=True).reset_index(level=1, names=["", "Ticker"]).sort_values(by="Ticker")
    data = data.reset_index(level=0) 
    data.columns = ['Date', 'Ticker', 'Close', 'High', 'Low', 'Open', 'Volume']
    data['Date'] = pd.to_datetime(data['Date'])
    data['Date_only'] = data['Date'].dt.date 
    data['Time_only'] = data['Date'].dt.time

    records = [(row['Ticker'], row['Date_only'], row['Time_only'], float(row['Open']), float(row['High']), float(row['Low']),
                float(row['Close']), row['Volume'])
            for _, row in data.iterrows()]

    insert_data_query = f"""
        INSERT INTO intraday_price_data (ticker_id, date, time, open, high, low, close, volume)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (ticker_id, date, time) DO NOTHING;
        """
    cursor.executemany(insert_data_query, records)
    conn.commit()
    cursor.close()

def update_historical_price_data(tickers, conn, period):
    """
    Fetches and updates historical stock price data for a list of tickers into the PostgreSQL database.

    For each ticker, this function retrieves historical data from Yahoo Finance over the specified period 
    and inserts it into the `historical_price_data` table. Existing entries (by ticker and date) are ignored.

    Args:
        tickers (list of str): List of stock ticker symbols to fetch historical data for.
        conn (psycopg2.connection): Active PostgreSQL database connection.
        period (str): The time period for which to retrieve data (e.g., '1d', '5d', '1mo', '6mo', '1y').

    Returns:
        None
    """
    cursor = conn.cursor()
    for ticker_id in tickers:
        ticker = yf.Ticker(ticker_id)
        historical_price_data = ticker.history(period=period)
        records = [(ticker_id, index, float(row['Open']), float(row['High']), float(row['Low']),
            float(row['Close']), int(row['Volume']))
           for index, row in historical_price_data.iterrows()]
        insert_data_query = f"""
        INSERT INTO historical_price_data (ticker_id, date, open, high, low, close, volume)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (ticker_id, date) DO NOTHING;
        """
        cursor.executemany(insert_data_query, records)
        conn.commit()
    cursor.close()

def update_technical_indicators(tickers, conn):
    """
    Calculates and updates technical indicators (MA5, MA20, MACD, Stochastic) for each ticker
    and stores them in the `technical_indicator` table of the PostgreSQL database.

    For each ticker, this function fetches historical price data from the `historical_price_data` table, 
    calculates the following technical indicators, and inserts them into the `technical_indicator` table:
        - Moving Average (MA) 5
        - Moving Average (MA) 20
        - Moving Average Convergence Divergence (MACD)
        - Stochastic Oscillator

    Existing entries (by ticker, date, and indicator) are ignored.

    Args:
        tickers (list of str): List of stock ticker symbols to calculate technical indicators for.
        conn (psycopg2.connection): Active PostgreSQL database connection.

    Returns:
        None
    """
    cursor = conn.cursor()
    for ticker_id in tickers:
        query = "SELECT * FROM historical_price_data WHERE ticker_id = %s ORDER BY date"
        df = pd.read_sql(query, conn, params=(ticker_id,))


        df['MA20'] = df['close'].rolling(window=20).mean()
        df['MA5'] = df['close'].rolling(window=5).mean()
        df['EMA12'] = df['close'].ewm(span=12, adjust=False).mean()
        df['EMA26'] = df['close'].ewm(span=26, adjust=False).mean()
        df['MACD'] = df['EMA12'] - df['EMA26']
        lowest_low = df['low'].rolling(14).min()
        highest_high = df['high'].rolling(14).max()
        df['stochastic'] = 100 * (df['close'] - lowest_low) / (highest_high - lowest_low)


        records = []

        df = df.dropna(subset=['MA20', 'MA5'])
        for _, row in df.iterrows():
            MA5_record = (ticker_id, row['date'], row['MA5'], "MA5")
            MA20_record = (ticker_id, row['date'], row['MA20'], "MA20")
            records.append(MA5_record)
            records.append(MA20_record)


        for _, row in df.iterrows():
            record = (ticker_id, row['date'], row['MACD'], "MACD")
            records.append(record)

        for _, row in df.iterrows():
            record = (ticker_id, row['date'], row['stochastic'], "stochastic")
            records.append(record)
    
        insert_data_query = f"""
                INSERT INTO technical_indicator (ticker_id, date, value, indicator)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (ticker_id, date, indicator) DO NOTHING;
            """
        cursor.executemany(insert_data_query, records)
        print("technical indicator for " + ticker_id + " completed")
        conn.commit()
        
    cursor.close()
