
create table ticker (
    ticker_id VARCHAR(10) PRIMARY KEY,
    exchange VARCHAR(50),
    currency VARCHAR(10),
    long_name VARCHAR(255),
    phone VARCHAR(50),
    website VARCHAR(255),
    industry VARCHAR(100),
    sector VARCHAR(100),
    long_business_summary TEXT,
    market_cap BIGINT,
    enterprise_value BIGINT,
    shares_outstanding BIGINT,
    float_shares BIGINT,
    held_percent_insiders DECIMAL(4, 3),
    held_percent_institutions DECIMAL(4, 3),
    book_value BIGINT,
    price_to_book DECIMAL(9, 3),
    total_cash BIGINT,
    total_debt BIGINT,
    total_revenue BIGINT,
    net_income_to_common DECIMAL(17, 2),
    trailing_eps DECIMAL(9, 3),
    beta DECIMAL(9, 3),
    current_ratio DECIMAL(9, 3),
    quick_ratio DECIMAL(9, 3),
    gross_margins DECIMAL(5, 3),
    operating_margins DECIMAL(12, 3),
    regular_market_price DECIMAL(10, 4),
    regular_market_change_percent DECIMAL(5, 2),
    fifty_two_week_low DECIMAL(10, 4),
    fifty_two_week_high DECIMAL(10, 4),
    fifty_day_average DECIMAL(12, 5),
    two_hundred_day_average DECIMAL(12, 5),
    average_volume BIGINT,
    volume BIGINT
);

create table balance_sheet (
    ticker_id VARCHAR(10),
    date DATE,
    ordinary_shares_number DECIMAL(15, 0),
    share_issued DECIMAL(15, 0),
    tangible_book_value DECIMAL(17, 2),
    invested_capital DECIMAL(17, 2),
    working_capital DECIMAL(17, 2),
    net_tangible_assets DECIMAL(17, 2),
    common_stock_equity DECIMAL(17, 2),
    total_capitalization DECIMAL(17, 2),
    total_equity_gross_minority_interest DECIMAL(17, 2),
    stockholders_equity DECIMAL(17, 2),
    gains_losses_not_affecting_retained_earnings DECIMAL(17, 2),
    other_equity_adjustments DECIMAL(17, 2),
    retained_earnings DECIMAL(17, 2),
    capital_stock DECIMAL(17, 2),
    common_stock DECIMAL(17, 2),
    total_liabilities_net_minority_interest DECIMAL(17, 2),
    total_non_current_liabilities_net_minority_interest DECIMAL(17, 2),
    current_liabilities DECIMAL(17, 2),
    payables_and_accrued_expenses DECIMAL(17, 2),
    payables DECIMAL(17, 2),
    other_payable DECIMAL(17, 2),
    accounts_payable DECIMAL(17, 2),
    total_assets DECIMAL(17, 2),
    total_non_current_assets DECIMAL(17, 2),
    net_ppe DECIMAL(17, 2),
    gross_ppe DECIMAL(17, 2),
    machinery_furniture_equipment DECIMAL(17, 2),
    current_assets DECIMAL(17, 2),
    receivables DECIMAL(17, 2),
    other_receivables DECIMAL(17, 2),
    accounts_receivable DECIMAL(17, 2),
    cash_cash_equivalents_and_short_term_investments DECIMAL(17, 2),
    cash_and_cash_equivalents DECIMAL(17, 2),
    cash_equivalents DECIMAL(17, 2),
    cash_financial DECIMAL(17, 2),
    PRIMARY KEY (ticker_id, date)--,
    -- FOREIGN KEY (ticker_id) REFERENCES ticker(ticker_id)
);

create table financials (
    ticker_id VARCHAR(10),
    date DATE,
    tax_effect_of_unusual_items DECIMAL(17, 2),
    tax_rate_for_calcs DECIMAL(5, 4),
    normalized_ebitda DECIMAL(17, 2),
    net_income_from_continuing_operation_net_minority_interest DECIMAL(17, 2),
    reconciled_depreciation DECIMAL(17, 2),
    ebitda DECIMAL(17, 2),
    ebit DECIMAL(17, 2),
    normalized_income DECIMAL(17, 2),
    net_income_from_continuing_and_discontinued_operations DECIMAL(17, 2),
    diluted_average_shares DECIMAL(17, 2),
    basic_average_shares DECIMAL(17, 2),
    diluted_eps DECIMAL(15, 4),
    basic_eps DECIMAL(15, 4),
    net_income_common_stockholders DECIMAL(17, 2),
    net_income DECIMAL(17, 2),
    net_income_including_noncontrolling_interests DECIMAL(17, 2),
    net_income_continuous_operations DECIMAL(17, 2),
    tax_provision DECIMAL(17, 2),
    pretax_income DECIMAL(17, 2),
    other_income_expense DECIMAL(17, 2),
    other_non_operating_income_expenses DECIMAL(17, 2),
    operating_income DECIMAL(17, 2),
    operating_expense DECIMAL(17, 2),
    other_operating_expenses DECIMAL(17, 2),
    depreciation_amortization_depletion_income_statement DECIMAL(17, 2),
    depreciation_and_amortization_in_income_statement DECIMAL(17, 2),
    depreciation_income_statement DECIMAL(17, 2),
    selling_general_and_administration DECIMAL(17, 2),
    general_and_administrative_expense DECIMAL(17, 2),
    other_gand_a DECIMAL(17, 2),
    salaries_and_wages DECIMAL(17, 2),
    PRIMARY KEY (ticker_id, date)--,
    -- FOREIGN KEY (ticker_id) REFERENCES ticker(ticker_id)
);

create table cash_flow (
    ticker_id VARCHAR(10),
    date DATE,
    free_cash_flow DECIMAL(17, 2),
    repurchase_of_capital_stock DECIMAL(17, 2),
    issuance_of_debt DECIMAL(17, 2),
    issuance_of_capital_stock DECIMAL(17, 2),
    capital_expenditure DECIMAL(17, 2),
    end_cash_position DECIMAL(17, 2),
    beginning_cash_position DECIMAL(17, 2),
    effect_of_exchange_rate_changes DECIMAL(17, 2),
    changes_in_cash DECIMAL(17, 2),
    financing_cash_flow DECIMAL(17, 2),
    cash_flow_from_continuing_financing_activities DECIMAL(17, 2),
    net_common_stock_issuance DECIMAL(17, 2),
    common_stock_payments DECIMAL(17, 2),
    common_stock_issuance DECIMAL(17, 2),
    net_issuance_payments_of_debt DECIMAL(17, 2),
    net_long_term_debt_issuance DECIMAL(17, 2),
    long_term_debt_issuance DECIMAL(17, 2),
    investing_cash_flow DECIMAL(17, 2),
    cash_flow_from_continuing_investing_activities DECIMAL(17, 2),
    net_ppe_purchase_and_sale DECIMAL(17, 2),
    purchase_of_ppe DECIMAL(17, 2),
    cash_flows_from_used_in_operating_activities_direct DECIMAL(17, 2),
    interest_received_direct DECIMAL(17, 2),
    classes_of_cash_payments DECIMAL(17, 2),
    other_cash_payments_from_operating_activities DECIMAL(17, 2),
    payments_to_suppliers_for_goods_and_services DECIMAL(17, 2),
    classes_of_cash_receipts_from_operating_activities DECIMAL(17, 2),
    other_cash_receipts_from_operating_activities DECIMAL(17, 2),
    PRIMARY KEY (ticker_id, date)--,
    -- FOREIGN KEY (ticker_id) REFERENCES ticker(ticker_id)
);

create table historical_price_data (
    ticker_id VARCHAR(10),
    date DATE,
    open DECIMAL(18, 4),
    high  DECIMAL(18, 4),
    low DECIMAL(18, 4),
    close DECIMAL(18, 4),
    volume BIGINT,
    PRIMARY KEY (ticker_id, date)--,
    -- FOREIGN KEY (ticker_id) REFERENCES ticker(ticker_id)
);

create table intraday_price_data (
    ticker_id VARCHAR(10),
    date DATE,
    time TIME,
    open DECIMAL(18, 4),
    high  DECIMAL(18, 4),
    low DECIMAL(18, 4),
    close DECIMAL(18, 4),
    volume DECIMAL(18, 0),
    PRIMARY KEY (ticker_id, date, time)
    -- FOREIGN KEY (ticker_id) REFERENCES ticker(ticker_id)
);

create table technical_indicator (
    ticker_id VARCHAR(10),
    date DATE,
    value DECIMAL(12, 3),
    indicator VARCHAR(32),
    PRIMARY KEY (ticker_id, date, indicator)
);

create table ticker_news (
    ticker_id VARCHAR(10),
    title VARCHAR(255),
    published TIMESTAMP,
    url TEXT,
    PRIMARY KEY (ticker_id, title)
);

create table macro_news (
    title VARCHAR(255) PRIMARY KEY,
    published TIMESTAMP,
    url TEXT
);

create table ticker_sentiment (
    ticker_id VARCHAR(10),
    sentiment TEXT,
    confidence DECIMAL(7, 4),
    num_articles_analysed INT,
    PRIMARY KEY (ticker_id)
);
