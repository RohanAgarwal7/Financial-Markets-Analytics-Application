import psycopg2 as pg
from sentence_transformers import SentenceTransformer
import chromadb
from edgar import *

set_identity("123@email.com")

#-------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------
""" 
This file is run locally in the termnal while docker is running.
It loads the tenk reports for a specified list of tickers, separates them into chunks, which are then added into chromaDB.
"""
#-------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------

def separate_text_to_overlapping_chunks(long_name, text, chunk_size, overlap_size):
    """
    Splits a long text into overlapping chunks and adds a custom prefix to each chunk.

    The function divides the input `text` into chunks of size `chunk_size`, where each chunk overlaps with
    the previous one by `overlap_size` characters. A custom prefix including `long_name` is added to each chunk.
    
    Args:
        long_name (str): A name or identifier to be included as a prefix in each chunk.
        text (str): The text to be split into overlapping chunks.
        chunk_size (int): The desired size of each chunk, in characters.
        overlap_size (int): The number of characters each chunk should overlap with the previous one.

    Returns:
        list of str: A list of text chunks with overlaps, each prefixed with the `long_name`.
    """

    chunks = []
    start = 0
    text_length = len(text)
    while start < text_length:
        end = start + chunk_size
        chunk = text[start:end]
        chunk = f"This piece of text relates to {long_name}\n" + chunk
        chunks.append(chunk)
        start = end - overlap_size 
    print(f"Split into {len(chunks)} chunks")
    return chunks

# Get chromaDB collection
client = chromadb.HttpClient(host='localhost', port=8000)
collection_name = "data"
collection = client.get_or_create_collection(
            collection_name,
            metadata={"hnsw:space": "cosine"}
        )
sentence_transformer_ef = SentenceTransformer('multi-qa-MiniLM-L6-cos-v1')

# Connect to postgreSQL database
HOSTNAME="localhost"
DATABASE='stock_data'
USERNAME='postgres'
PASSWORD='postgres'
PORT='9999'
conn = pg.connect(
    host=HOSTNAME,
    user=USERNAME,
    password=PASSWORD,
    dbname=DATABASE,
    port=PORT
)
cursor = conn.cursor()


def add_tenk_report_to_chroma(ticker_id):
    """
    Adds the latest 10-K report of a company to the Chroma database as overlapping text chunks.

    This function retrieves the latest 10-K report for a given company identified by `ticker_id`, splits the report
    into overlapping chunks, and then inserts each chunk into the Chroma database for indexing. Each chunk is
    embedded using a sentence transformer model, and associated metadata is added to facilitate future retrieval.

    Args:
        ticker_id (str): The unique identifier for the company (ticker symbol).

    Returns:
        None: This function does not return any value. It either adds the chunks to the Chroma database or does nothing
              in case of an error or invalid ticker.

    Notes:
        - The function ignores ticker symbols ending in ".AX" (presumably Australian companies).
        - The function handles the retrieval of the company's 10-K report and processes it in chunks of 1200 characters
          with an overlap of 300 characters between consecutive chunks.
    
    Example:
        add_tenk_report_to_chroma("AAPL") 
        # This will retrieve the latest 10-K report for Apple, split it into chunks, 
        # and add those chunks to the Chroma database.
    """
     
    cursor.execute("SELECT long_name FROM ticker WHERE ticker_id = %s LIMIT 1", (ticker_id,))
    row = cursor.fetchone()
    ticker_long_name = row[0] if row else None
    
    if ticker_id.endswith(".AX"):
        return 
    
    try:
        company = Company(ticker_id)
        tenk = company.latest("10-K").text()
        chunks = separate_text_to_overlapping_chunks(ticker_long_name, tenk, 1200, 300)
        
        documents, metadatas, ids = [], [], []
        for j, chunk in enumerate(chunks, 1):
            metadatas.append({"ticker": ticker_id, "title": "tenk"})
            ids.append(f"{ticker_id}_tenk_chunk_{j}")
            documents.append(chunk)
        
        embeddings = sentence_transformer_ef.encode(documents).tolist()
        collection.upsert(
            embeddings=embeddings,
            documents=documents,
            metadatas=metadatas,
            ids=ids
        )
        return
    
    except Exception as e:
        return 



# List of tickers to get tenk reports for
tickers = ["TSLA", "AAPL", "WOW.AX", "CBA.AX", "NVDA", "GC=F", "^AXJO", "^NYA", "^IXIC"]

for ticker_id in tickers:
    add_tenk_report_to_chroma(ticker_id)
