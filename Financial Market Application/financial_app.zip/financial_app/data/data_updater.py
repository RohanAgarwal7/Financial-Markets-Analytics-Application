import psycopg2 as pg
import time
from news_helper import *
from SQL_update_helper import *
from chroma_helper import *
from datetime import datetime
import chromadb
from chromadb.utils import embedding_functions
import numpy as np
import torch
import json


device = 'cuda' if torch.cuda.is_available() else 'cpu'

# Initialise embedding function for converting documents into vectors for ChromaDB
sentence_transformer_ef = embedding_functions.SentenceTransformerEmbeddingFunction(
    model_name="multi-qa-MiniLM-L6-cos-v1",
    device=device
)

# Get ChromaDB collection
chroma_client = chromadb.HttpClient(host='chromadb', port=8000)
collection_name = "data"
try:
    collection = chroma_client.get_or_create_collection(
        collection_name,
        metadata={"hnsw:space": "cosine"}
    )
    print("Connection established", flush=True)
except Exception as e:
    print(f"Error creating or accessing collection: {e}")

    
def log(message):
    """
    Logs a message with a timestamp.
    This function prints a message to the console with the current timestamp in the format 
    YYYY-MM-DD HH:MM:SS. 

    Args:
        message (str): The message to log.

    Returns:
        None: The function does not return any value but outputs the log message to the console.
    """
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{timestamp}] {message}", flush=True)

DAILY_INTERVAL = 86400
INTRADAY_DATA_INTERVAL = 300 # Unused due to change in app requirements, but kept for future work

# List of RSS feeds to source news from
RSS_feeds = [
    "https://thewest.com.au/business/rss",
    "https://feeds.bbci.co.uk/news/business/rss.xml"
]


def get_db_connection(retry_delay=10):
    """
    Establishes a connection to the PostgreSQL database.

    This function attempts to connect to the PostgreSQL database using the provided connection 
    parameters. If the connection attempt fails, it will retry after a delay specified by 
    the `retry_delay` parameter. This is the protect against errors that may occur 
    if this docker container is ready before the postgreSQL docker container is ready for connections.

    Args:
        retry_delay (int, optional): The number of seconds to wait before retrying a failed 
                                      connection attempt. Defaults to 10 seconds.

    Returns:
        conn: A psycopg2 connection object to the PostgreSQL database.

    Raises:
        None: The function will retry indefinitely until a successful connection is established.

    Example:
        conn = get_db_connection(retry_delay=5)
        # If the connection is successful, conn will be a valid database connection object.
    """
     
    HOSTNAME = "financial_data"
    DATABASE = 'stock_data'
    USERNAME = 'postgres'
    PASSWORD = 'postgres'
    PORT = '5432'
    
    while True:
        try:
            conn = pg.connect(
                host=HOSTNAME,
                user=USERNAME,
                password=PASSWORD,
                dbname=DATABASE,
                port=PORT
            )
            print("Successfully connected to database")
            return conn
        except Exception as e:
            time.sleep(retry_delay)


def convert_ndarrays(obj):
    """
    Recursively converts numpy ndarrays to lists for JSON serialization. 
    Used for storing chromaDB database locally as a json file.
    
    Args:
        obj: The object to convert, can be a numpy ndarray, dictionary, or list.

    Returns:
        The input object with all numpy ndarrays converted to lists.
    """
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, dict):
        return {k: convert_ndarrays(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [convert_ndarrays(v) for v in obj]
    return obj

conn = get_db_connection(10)
cursor = conn.cursor()

# Delete existing intraday_price_data to save database space
# Feature no longer required as intraday data not in requirements anymore
cursor.execute("TRUNCATE TABLE intraday_price_data")
conn.commit()

# List of tickers to keep up to date
ticker_list = ["TSLA", "AAPL", "WOW.AX", "CBA.AX", "NVDA", "GC=F", "^AXJO", "^NYA", "^IXIC"]

cursor.execute("select * from ticker WHERE ticker_id = ANY(%s)", (ticker_list,))
# get ticker info table
tickers = cursor.fetchall()

cursor.execute("select * from balance_sheet  WHERE ticker_id = ANY(%s)", (ticker_list,))
# get balance sheet table
balance_sheets = cursor.fetchall()

cursor.execute("select * from financials  WHERE ticker_id = ANY(%s)", (ticker_list,))
# get financials table
financialss = cursor.fetchall()

cursor.execute("select * from cash_flow  WHERE ticker_id = ANY(%s)", (ticker_list,))
# get cash flows table
cash_flows = cursor.fetchall()

# Add information from the tables into the ChromaDB collection
# Functions defined in chroma_helper.py
add_stock_information(cursor, tickers, collection, sentence_transformer_ef, 1000, create_ticker_paragraph, "stock_report", "report")
add_stock_information(cursor, balance_sheets, collection, sentence_transformer_ef, 1000, create_balance_sheet_paragraph, "balance_sheet", "balance_sheet")
add_stock_information(cursor, financialss, collection, sentence_transformer_ef, 1000, create_financials_paragraph, "financials", "financials")
add_stock_information(cursor, cash_flows, collection, sentence_transformer_ef, 1000, create_cash_flow_paragraph, "cash_flow", "cash_flow")

cursor.close()

total_runtime = 0
historical_price_period = '10y'

# With the removal of intraday data functionality, this while loop for all purposes runs on a daily interval.
while True:
    # Intraday_data maintenance functionality currently commented out due to change in app requirements. Kept for convenience if future work is done.
    # update_intraday_data(ticker_list, conn) 
    # log("Updated intraday data")

    if total_runtime != 0:
        historical_price_period = '1d'

    if total_runtime % DAILY_INTERVAL == 0:
        update_historical_price_data(ticker_list, conn, historical_price_period)
        log("Updated historical price data")
        update_technical_indicators(ticker_list, conn)
        log("Updated technical indicator data")
        scrapeYahooTickerNews(ticker_list, conn)
        log("Updated yfinance news")
        scrapeRSSFeedsIntoDatabase(RSS_feeds, conn)
        log("Updated RSS feed news")
        scrapeFinlightFeedIntoDatabase(conn)
        log("Analysing sentiment...")
        process_ticker_batch_sentiments(ticker_list, conn)
        log("Sentiment analysis complete")

        # Load chromaDB collection with local database
        with open("chroma_collection_export.json", "r") as f:
            data = json.load(f)

        collection.add(
            ids=data["ids"],
            documents=data["documents"],
            embeddings=data["embeddings"],
            metadatas=data["metadatas"]
        )

        # Update chromaDB collection but inserting new news
        log("Adding news to chroma db...")
        cursor = conn.cursor()
        cursor.execute("select ticker_id, title, url, published from ticker_news")
        ticker_news = cursor.fetchall()
        cursor.execute("select 'general' as ticker_id, title, url, published from macro_news")
        macro_news = cursor.fetchall()
        cursor.close()
        add_news(ticker_news + macro_news, collection, sentence_transformer_ef)
        log("Chroma db finished populating...")
        
        # Save a local copy of updated chromaDB collection
        all_docs = collection.get(include=['embeddings', 'metadatas', 'documents'])
        all_docs_clean = convert_ndarrays(all_docs)
        with open("chroma_collection_export.json", "w") as f:
            json.dump(all_docs_clean, f)

    time.sleep(300)
    total_runtime += 300
    
    
