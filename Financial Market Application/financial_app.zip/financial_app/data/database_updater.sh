#!/bin/bash
set -e

sleep 20

echo "Updating database..."

python /app/data_updater.py
