from newspaper import Article


def create_ticker_paragraph(ticker, cursor):
    """
    Converts a PostgreSQL ticker tuple into a formatted descriptive paragraph for embedding in ChromaDB.

    This function takes a tuple of financial and metadata fields for a specific stock ticker and returns a 
    structured natural language summary, making it easier to perform semantic search over the data.

    Args:
        ticker (tuple): A tuple containing ticker-related fields retrieved from the PostgreSQL database.
        cursor (psycopg2.extensions.cursor): active database cursor

    Returns:
        str: A detailed descriptive paragraph summarizing the company's key information and financials.
    """  

    (ticker_id, exchange, currency, long_name, phone, website, industry, sector, 
    long_business_summary, market_cap, enterprise_value, shares_outstanding, float_shares, 
    held_percent_insiders, held_percent_institutions, book_value, price_to_book, total_cash, 
    total_debt, total_revenue, net_income_to_common, trailing_eps, beta, current_ratio, 
    quick_ratio, gross_margins, operating_margins, regular_market_price, regular_market_change_percent, 
    fifty_two_week_low, fifty_two_week_high, fifty_day_average, two_hundred_day_average, 
    average_volume, volume) = ticker

    paragraph = f"""
    The company {long_name} ({ticker_id}), listed on the {exchange} exchange and trading in {currency}, operates within the {industry} sector, under the {sector} industry. 
    The company offers the following business summary: {long_business_summary}.

    As of the latest data, {long_name} has a market capitalization of {market_cap if market_cap != '(unavailable)' else '(unavailable)'} and an enterprise value of {enterprise_value if enterprise_value != '(unavailable)' else '(unavailable)'}. 
    The company has {shares_outstanding if shares_outstanding != '(unavailable)' else '(unavailable)'} shares outstanding, with {float_shares if float_shares != '(unavailable)' else '(unavailable)'} shares available for trading. 
    {held_percent_insiders}% of the shares are held by insiders, and {held_percent_institutions}% are held by institutions.

    Financial highlights include a book value of {book_value if book_value != '(unavailable)' else '(unavailable)'}, a price-to-book ratio of {price_to_book if price_to_book != '(unavailable)' else '(unavailable)'},
    total cash of {total_cash if total_cash != '(unavailable)' else '(unavailable)'}, and total debt of {total_debt if total_debt != '(unavailable)' else '(unavailable)'}.
    The total revenue for the most recent period is {total_revenue if total_revenue != '(unavailable)' else '(unavailable)'}, 
    with a net income to common shareholders of {net_income_to_common if net_income_to_common != '(unavailable)' else '(unavailable)'} and a trailing earnings per share (EPS) of {trailing_eps if trailing_eps != '(unavailable)' else '(unavailable)'}.

    The company has a beta of {beta if beta != '(unavailable)' else '(unavailable)'}, indicating its stock price volatility compared to the broader market. 
    Its current ratio is {current_ratio if current_ratio != '(unavailable)' else '(unavailable)'}, and the quick ratio is {quick_ratio if quick_ratio != '(unavailable)' else '(unavailable)'},
    reflecting its liquidity position. Gross margins are {gross_margins if gross_margins != '(unavailable)' else '(unavailable)'}%, and operating margins stand at {operating_margins if operating_margins != '(unavailable)' else '(unavailable)'}%.

    The 52-week low and high for the stock are {fifty_two_week_low if fifty_two_week_low != '(unavailable)' else '(unavailable)'} and {fifty_two_week_high if fifty_two_week_high != '(unavailable)' else '(unavailable)'},
    respectively. The 50-day and 200-day averages are {fifty_day_average if fifty_day_average != '(unavailable)' else '(unavailable)'} and {two_hundred_day_average if two_hundred_day_average != '(unavailable)' else '(unavailable)'},
    respectively.
    """
    return paragraph


def create_balance_sheet_paragraph(balance_sheet, cursor):
    """
    Converts balance sheet data from a PostgreSQL record into a formatted descriptive paragraph for ChromaDB.

    This function takes a tuple of balance sheet values for a specific ticker and returns a structured 
    natural language summary, which can be embedded into a vector database for retrieval-based applications.

    Args:
        balance_sheet (tuple): A tuple containing balance sheet values for a company, retrieved from the database.
        cursor (psycopg2.extensions.cursor): Active database cursor used to fetch the company long name.

    Returns:
        str: A structured paragraph summarizing the key figures from the company's balance sheet.
    """
    (ticker_id, date, ordinary_shares_number, share_issued, tangible_book_value, 
    invested_capital, working_capital, net_tangible_assets, common_stock_equity, 
    total_capitalization, total_equity_gross_minority_interest, stockholders_equity, 
    gains_losses_not_affecting_retained_earnings, other_equity_adjustments, retained_earnings, 
    capital_stock, common_stock, total_liabilities_net_minority_interest,
    total_non_current_liabilities_net_minority_interest, current_liabilities, 
    payables_and_accrued_expenses, payables, other_payable, accounts_payable, 
    total_assets, total_non_current_assets, net_ppe, gross_ppe, 
    machinery_furniture_equipment, current_assets, receivables, other_receivables, 
    accounts_receivable, cash_cash_equivalents_and_short_term_investments, 
    cash_and_cash_equivalents, cash_equivalents, cash_financial) = balance_sheet

    cursor.execute(f"select long_name from ticker where ticker_id = %s", (ticker_id,))
    result = cursor.fetchone()
    long_name = "(information unavailable)" if not result else result[0]

    paragraph = f"""
    The balance sheet of {long_name} ({ticker_id}) as of {date} reflects the following key figures:

    The company has {total_assets if total_assets is not None else '(unavailable)'} in total assets, with {total_liabilities_net_minority_interest if total_liabilities_net_minority_interest is not None else '(unavailable)'} in total liabilities, 
    leading to stockholders' equity of {stockholders_equity if stockholders_equity is not None else '(unavailable)'}. The tangible book value is {tangible_book_value if tangible_book_value is not None else '(unavailable)'}, 
    and invested capital stands at {invested_capital if invested_capital is not None else '(unavailable)'}.

    In terms of liabilities, {long_name} has {current_liabilities if current_liabilities is not None else '(unavailable)'} in current liabilities, including payables totaling {payables if payables is not None else '(unavailable)'} 
    and accounts payable of {accounts_payable if accounts_payable is not None else '(unavailable)'}. The total non-current liabilities are {total_non_current_liabilities_net_minority_interest if total_non_current_liabilities_net_minority_interest is not None else '(unavailable)'}, 
    contributing to the overall capitalization of {total_capitalization if total_capitalization is not None else '(unavailable)'}.

    Regarding assets, the company holds {current_assets if current_assets is not None else '(unavailable)'} in current assets, with {cash_and_cash_equivalents if cash_and_cash_equivalents is not None else '(unavailable)'} in cash and cash equivalents. 
    Non-current assets amount to {total_non_current_assets if total_non_current_assets is not None else '(unavailable)'}, with {net_ppe if net_ppe is not None else '(unavailable)'} in net property, plant, and equipment (PPE) and 
    {gross_ppe if gross_ppe is not None else '(unavailable)'} in gross PPE. The company has {receivables if receivables is not None else '(unavailable)'} in receivables, including {accounts_receivable if accounts_receivable is not None else '(unavailable)'} in accounts receivable.

    The company has {ordinary_shares_number if ordinary_shares_number is not None else '(unavailable)'} ordinary shares outstanding, and its retained earnings total {retained_earnings if retained_earnings is not None else '(unavailable)'}. 
    The company's working capital is {working_capital if working_capital is not None else '(unavailable)'}, reflecting its ability to cover short-term obligations.
    """
    return paragraph


def create_financials_paragraph(financials, cursor):
    """
    Converts income statement financial data from a PostgreSQL record into a structured paragraph 
    suitable for embedding in a retrieval-augmented generation (RAG) context.

    This function summarizes key income statement metrics such as EBITDA, EBIT, net income, taxes,
    and earnings per share for a specific company and date.

    Args:
        financials (tuple): A tuple containing financial performance metrics of a company.
        cursor (psycopg2.extensions.cursor): Active database cursor used to fetch the company long name.

    Returns:
        str: A paragraph summarizing financial highlights for the company.
    """
    (ticker_id, date, tax_effect_of_unusual_items, tax_rate_for_calcs, normalized_ebitda,
    net_income_from_continuing_operation_net_minority_interest, reconciled_depreciation,
    ebitda, ebit, normalized_income, net_income_from_continuing_and_discontinued_operations,
    diluted_average_shares, basic_average_shares, diluted_eps, basic_eps,
    net_income_common_stockholders, net_income, net_income_including_noncontrolling_interests,
    net_income_continuous_operations, tax_provision, pretax_income, other_income_expense,
    other_non_operating_income_expenses, operating_income, operating_expense,
    other_operating_expenses, depreciation_amortization_depletion_income_statement,
    depreciation_and_amortization_in_income_statement, depreciation_income_statement,
    selling_general_and_administration, general_and_administrative_expense,
    other_gand_a, salaries_and_wages) = financials

    cursor.execute(f"select long_name from ticker where ticker_id = %s", (ticker_id,))
    result = cursor.fetchone()
    long_name = "(information unavailable)" if not result else result[0]

    paragraph = f"""
    This relates to the financials of the company {ticker_id}, or alternatively called {long_name}.
    As of {date}, the company reported a net income of {net_income if net_income is not None else '(unavailable)'}, with an EBITDA of {ebitda if ebitda is not None else '(unavailable)'} and EBIT of {ebit if ebit is not None else '(unavailable)'}. 
    Pre-tax income stood at {pretax_income if pretax_income is not None else '(unavailable)'}, while tax provisions amounted to {tax_provision if tax_provision is not None else '(unavailable)'}, 
    leading to an effective tax rate of {tax_rate_for_calcs if tax_rate_for_calcs is not None else '(unavailable)'}%.
    
    Operating income was {operating_income if operating_income is not None else '(unavailable)'}, while total operating expenses reached {operating_expense if operating_expense is not None else '(unavailable)'}. 
    The company incurred {salaries_and_wages if salaries_and_wages is not None else '(unavailable)'} in salaries and wages expenses, with selling, general, and administrative 
    expenses totaling {selling_general_and_administration if selling_general_and_administration is not None else '(unavailable)'}. 

    The company's depreciation and amortization expenses in the income statement were {depreciation_amortization_depletion_income_statement if depreciation_amortization_depletion_income_statement is not None else '(unavailable)'}, 
    while other operating expenses stood at {other_operating_expenses if other_operating_expenses is not None else '(unavailable)'}. Other income and expenses, including non-operating items, 
    amounted to {other_income_expense if other_income_expense is not None else '(unavailable)'}.

    In terms of earnings per share, diluted EPS was {diluted_eps if diluted_eps is not None else '(unavailable)'}, while basic EPS stood at {basic_eps if basic_eps is not None else '(unavailable)'}. 
    The company had an average of {diluted_average_shares if diluted_average_shares is not None else '(unavailable)'} diluted shares outstanding.
    """
    return paragraph

def create_cash_flow_paragraph(cash_flow, cursor):
    """
    Converts cash flow statement data from a PostgreSQL record into a structured natural 
    language paragraph for retrieval-augmented generation (RAG) applications.

    Args:
        cash_flow (tuple): A tuple containing cash flow metrics of a company.
        cursor (psycopg2.extensions.cursor): Active database cursor used to fetch the company long name.

    Returns:
        str: A paragraph summarizing cash flow activities for the company.
    """
    (ticker_id, date, free_cash_flow, repurchase_of_capital_stock, issuance_of_debt, 
    issuance_of_capital_stock, capital_expenditure, end_cash_position, beginning_cash_position, 
    effect_of_exchange_rate_changes, changes_in_cash, financing_cash_flow, 
    cash_flow_from_continuing_financing_activities, net_common_stock_issuance, common_stock_payments, 
    common_stock_issuance, net_issuance_payments_of_debt, net_long_term_debt_issuance, long_term_debt_issuance, 
    investing_cash_flow, cash_flow_from_continuing_investing_activities, net_ppe_purchase_and_sale, purchase_of_ppe, 
    cash_flows_from_used_in_operating_activities_direct, interest_received_direct, classes_of_cash_payments, 
    other_cash_payments_from_operating_activities, payments_to_suppliers_for_goods_and_services, 
    classes_of_cash_receipts_from_operating_activities, other_cash_receipts_from_operating_activities) = cash_flow

    cursor.execute("SELECT long_name FROM ticker WHERE ticker_id = %s", (ticker_id,))
    result = cursor.fetchone()
    long_name = "(information unavailable)" if not result else result[0]

    paragraph = f"""
    This cash flow statement is for the company {ticker_id}, also known as {long_name}.
    As of {date}, the company reported free cash flow of {free_cash_flow if free_cash_flow is not None else '(unavailable)'}, with capital expenditures amounting to {capital_expenditure if capital_expenditure is not None else '(unavailable)'}.
    
    In terms of financing activities, the firm had a financing cash flow of {financing_cash_flow if financing_cash_flow is not None else '(unavailable)'}, 
    with {issuance_of_debt if issuance_of_debt is not None else '(unavailable)'} raised from debt issuance and {issuance_of_capital_stock if issuance_of_capital_stock is not None else '(unavailable)'} from capital stock issuance.
    Meanwhile, the company repurchased {repurchase_of_capital_stock if repurchase_of_capital_stock is not None else '(unavailable)'} in capital stock.
    
    The company started with {beginning_cash_position if beginning_cash_position is not None else '(unavailable)'} in cash and ended the period with {end_cash_position if end_cash_position is not None else '(unavailable)'}, 
    reflecting a net change in cash of {changes_in_cash if changes_in_cash is not None else '(unavailable)'}. Exchange rate fluctuations had an effect of {effect_of_exchange_rate_changes if effect_of_exchange_rate_changes is not None else '(unavailable)'}.
    
    On the investing side, the company reported investing cash flow of {investing_cash_flow if investing_cash_flow is not None else '(unavailable)'}, with {net_ppe_purchase_and_sale if net_ppe_purchase_and_sale is not None else '(unavailable)'} 
    in net PPE transactions and {purchase_of_ppe if purchase_of_ppe is not None else '(unavailable)'} used for PPE purchases.
    
    Operating activities contributed {cash_flows_from_used_in_operating_activities_direct if cash_flows_from_used_in_operating_activities_direct is not None else '(unavailable)'} in cash flows, with {payments_to_suppliers_for_goods_and_services if payments_to_suppliers_for_goods_and_services is not None else '(unavailable)'} 
    paid to suppliers and {interest_received_direct if interest_received_direct is not None else '(unavailable)'} received in interest.
    
    Overall, this cash flow statement provides insights into {long_name}'s liquidity and cash management for the period.
    """
    return paragraph


def add_stock_information(cursor, data, collection, sentence_transformer_ef, batch_size, paragraph_format, title, string_appended_to_id):
    """
    Adds stock information into the ChromaDB collection.

    Args:
        cursor (psycopg2.cursor): The database cursor used to fetch data from the database.
        data (list): A list of data to add, where each index corresponds to an individual ticker.
        collection (chromadb.Collection): The ChromaDB collection to add the data to.
        sentence_transformer_ef (function): The embedding model used to generate embeddings for the documents.
        batch_size (int): The number of tickers to insert into the collection in a single batch.
        paragraph_format (function): A function that formats the data into a more queriable format.
        title (str): The type of data being inserted (used for filtering results when querying ChromaDB).
        string_appended_to_id (str): Text appended to the end of the ID for easier filtering when retrieving documents.

    Returns:
        None: The function does not return a value but inserts the data into the ChromaDB collection.
    """
    documents, metadatas, ids = [], [], []
    tickers_done = 0
    ticker_count = {} 
    
    # for each ticker
    for row in data:
        ticker_id = row[0]
        tickers_done += 1

        # Incrementing count for each ticker for the purposes of creating id for each insertion
        if ticker_id in ticker_count:
            ticker_count[ticker_id] += 1
        else:
            ticker_count[ticker_id] = 1

        documents.append(paragraph_format(row, cursor))
        metadatas.append({"ticker": ticker_id, "title": title, "has_publish_date": False})
        ids.append(f"{ticker_id}_{string_appended_to_id}{ticker_count[ticker_id]}")

        # Insertion of data into chromadb once batch_size is reached
        if len(documents) >= batch_size:
            embeddings = sentence_transformer_ef(documents)
            collection.upsert(embeddings=embeddings, documents=documents, metadatas=metadatas, ids=ids)
            print(str(len(documents)) + " documents collated")
            documents, metadatas, ids = [], [], []

        count = collection.count()
        print(f"Number of documents in collection: {count}")

    # Remaining documents (if batch_size was not reached) are then inserted as well
    if documents:
        embeddings = sentence_transformer_ef(documents)
        collection.upsert(embeddings=embeddings, documents=documents, metadatas=metadatas, ids=ids)
        print(f"Added remaining {len(documents)} tickers to ChromaDB")

    print(str(tickers_done) + " documents collated in total")


def add_news(news, collection, embedding_function):
    """
    Adds news articles to a ChromaDB collection.

    This function checks for existing articles in the collection to avoid duplicates based on their title. 
    It fetches articles, processes them, and upserts the documents into ChromaDB in batches. 
    It also includes metadata like the publish date for filtering purposes.

    Args:
        news (list): A list of tuples, each containing the following fields:
            - ticker_id (str): The stock ticker associated with the news article.
            - title (str): The title of the news article.
            - url (str): The URL to the full news article.
            - publish_date (datetime): The publish date of the article.
        collection (chromadb.Collection): The ChromaDB collection to which the news articles will be added.
        embedding_function (function): The function used to generate embeddings for the news articles.

    Returns:
        None: The function does not return a value but adds the processed news articles to the ChromaDB collection.

    Side effects:
        - Inserts the news articles into the ChromaDB collection in batches.
        - Skips duplicate articles based on their title and content.
    """

    # Get existing titles in the collection to skip any duplicate news
    all_data = collection.get(include=["documents", "metadatas"])
    existing_titles = set(meta["title"] for meta in all_data["metadatas"])

    documents, metadatas, ids = [], [], []

    existing_ids = set()
    batch_size = 20

    num_skipped = 0
    for ticker_id, title, url, published in (news):
        
        # If the article is already in the collection
        if title in existing_titles:
            num_skipped += 1
            continue  
        
        news_article = Article(url)
        try:
            news_article.download()
            news_article.parse()
        except Exception as e:
            # Article could not be downloaded
            continue 
        
        # Prepending of sentence describing the date the article was published
        # Purpose is to make queries to the collection to be able to identify the date the article was published
        text = f"This text was published on {published}.\n" + news_article.text
        id = f"{ticker_id}_{hash(text)}"

        # Check if news article is the same as an article already in chroma_db, but just with a different title
        if id in existing_ids:
            continue
        
        print(title, flush=True)
        
        unix_timestamp = int(published.timestamp())

        existing_ids.add(id)
        documents.append(text)
        # Include publish_date metadata so that it can be filtered by date
        metadatas.append({"ticker": ticker_id, "title": title, "has_publish_date": True, "publish_date": unix_timestamp})
        ids.append(id)

        # Insertion of data into chromadb once batch_size is reached
        if len(documents) >= batch_size:
            embeddings = embedding_function(documents)
            collection.upsert(embeddings=embeddings, documents=documents, metadatas=metadatas, ids=ids)
            print(f"Added {len(documents)} articles to ChromaDB", flush=True)
            documents, metadatas, ids = [], [], []

    # Remaining documents (if batch_size was not reached) are then inserted as well
    if documents:
        embeddings = embedding_function(documents)
        collection.upsert(embeddings=embeddings, documents=documents, metadatas=metadatas, ids=ids)

    print(f"Skipped {num_skipped} articles already in database", flush=True)
