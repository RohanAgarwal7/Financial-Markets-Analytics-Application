import pandas as pd
import psycopg2 as pg


def checkForConflict(cursor, table, attributes, values):
    """
    Checks if a record with specific attribute values already exists in a given database table.

    Constructs and executes a SQL query to check for the existence of a row in the specified table
    where the provided attributes match the given values.

    Args:
        cursor (psycopg2.cursor): A cursor object used to execute the SQL query.
        table (str): The name of the table to check for conflicts.
        attributes (list): A list of column names to include in the WHERE clause.
        values (tuple): A tuple of values corresponding to the attributes.

    Returns:
        bool: True if a matching record exists, False otherwise.
    """
    conditions = " AND ".join([f"{col} = %s" for col in attributes])
    query = f"SELECT EXISTS (SELECT 1 FROM {table} WHERE {conditions});"

    cursor.execute(query, values)
    return cursor.fetchone()[0]
