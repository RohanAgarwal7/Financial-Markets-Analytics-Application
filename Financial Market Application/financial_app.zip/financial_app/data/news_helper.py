import xmltodict
import requests
from query_db_helper import checkForConflict
import datetime
import yfinance as yf

def get_articles_from_past_month(page):
    """
    Fetches business-related news articles from the past month using the Finlight API.

    Args:
        page (int): The page number to retrieve.

    Returns:
        dict or None: A dictionary containing the API response data if successful,
                      otherwise None in case of an error.

    Raises:
        HTTPError: If the HTTP request returns an unsuccessful status code.
        Exception: For any other exceptions that may occur during the request.
    """
    from_date = (datetime.datetime.today() - datetime.timedelta(days=30)).strftime('%Y-%m-%d')
    url = f'https://api.finlight.me/v1/articles?query=business&from={from_date}&pageSize=100&page={page}'
    headers = {
        'accept': 'application/json',
        'X-API-KEY': 'sk_1497997565040d0a73878b8876b028b3448c92632b63bc3093e7c4f3b52525c0',
    }
    # Free API using temp email so API KEY not that important
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status() 
        print("Successfully retrieved finlight data")
        return response.json()
    except requests.exceptions.HTTPError as http_err:
        print(f'HTTP error occurred: {http_err}')
    except Exception as err:
        print(f'An error occurred: {err}')


def scrapeFinlightFeedIntoDatabase(conn):
    """
    Scrapes business news articles from the Finlight API and inserts them into the `macro_news` table.

    This function paginates through all available articles from the past month using the
    `get_articles_from_past_month` function. Each article's title, publish date, and URL
    are inserted into the database. Duplicate entries (based on title) are ignored.

    Args:
        conn (psycopg2.connection): A PostgreSQL database connection object.

    Raises:
        Exception: If any unexpected error occurs during data fetching or database insertion.
    """
    cursor = conn.cursor()
    page = 1
    while True:     
        print("Parsing page " + str(page))
        articles = get_articles_from_past_month(page)['articles']
        if not articles:
            print("Collation from Finlight feed completed")
            print("----------------------------------------------------")
            break
        records = []
        for article in articles:
            print(article['title'])
            record = (article['title'], article['publishDate'], article['link'])
            records.append(record)

        insert_data_query = f"""
        INSERT INTO macro_news (title, published, url)
        VALUES (%s, %s, %s)
        ON CONFLICT (title) DO NOTHING;
        """
        cursor.executemany(insert_data_query, records)
        conn.commit()
        page = page + 1
    cursor.close()


def getRSS(url: str) -> dict:
    """
    Fetches and parses an RSS feed from the provided URL.

    Sends a GET request to the given RSS feed URL and parses the XML response
    into a Python dictionary using `xmltodict`.

    Args:
        url (str): The URL of the RSS feed.

    Returns:
        dict: A dictionary representation of the RSS feed content.
    """
    response = requests.get(url)
    return xmltodict.parse(response.content)

def scrapeRSSFeedsIntoDatabase(feeds, conn):
    """
    Fetches and stores articles from a list of RSS feeds into the macro_news table in the database.

    For each feed URL, the function retrieves the RSS data, extracts article information,
    and inserts it into the 'macro_news' table, avoiding duplicates based on the article title.

    Args:
        feeds (list): A list of RSS feed URLs to fetch articles from.
        conn (psycopg2.connection): A connection object to the PostgreSQL database.

    Returns:
        None
    """
    cursor = conn.cursor()
    for feed_url in feeds:
        data = getRSS(feed_url)
        macro_news_insert_query = f"""
                                INSERT INTO macro_news (title, published, url)
                                VALUES (%s, %s, %s) ON CONFLICT (title) DO NOTHING;
                            """
        articles = data['rss']['channel']['item']

        macro_records = []
        for article in articles:
            title = article.get('title') or None
            link = article.get('link') or None
            pubDate = article.get('pubDate') or None
            
            if checkForConflict(cursor, "macro_news", ["title"], (title,)):
                continue

            macro_records.append((title, pubDate, link))

        cursor.executemany(macro_news_insert_query, macro_records)
        print(f"Collation from {feed_url} complete")
        conn.commit()
    cursor.close()

def scrapeYahooTickerNews(tickers, conn):
    """
    Fetches and stores news articles for a list of stock tickers from Yahoo Finance.

    For each ticker, the function retrieves recent news articles using yfinance,
    checks for duplicates in the database based on ticker ID and article title,
    and inserts new articles into the 'ticker_news' table.

    Args:
        tickers (list): A list of stock ticker symbols (e.g., ['AAPL', 'MSFT']).
        conn (psycopg2.connection): A connection object to the PostgreSQL database.

    Returns:
        None
    """
    cursor = conn.cursor()
    for ticker_id in tickers:
        ticker = yf.Ticker(ticker_id)
        ticker_news = ticker.news
        records = []
        for article in ticker_news:
            content = article['content']
            if checkForConflict(cursor, "ticker_news", ["ticker_id", "title"], (ticker_id, content['title'],)):
                continue
            record = (ticker_id, content['title'], content['pubDate'], content['canonicalUrl']['url'])
            records.append(record)

        insert_data_query = f"""
        INSERT INTO ticker_news (ticker_id, title, published, url)
        VALUES (%s, %s, %s, %s)
        ON CONFLICT (ticker_id, title) DO NOTHING;
        """
        cursor.executemany(insert_data_query, records)
        conn.commit()
    cursor.close()
