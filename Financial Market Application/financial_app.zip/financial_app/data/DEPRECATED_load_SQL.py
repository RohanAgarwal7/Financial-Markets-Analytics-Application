import json
import yfinance as yf
import pandas as pd
import psycopg2 as pg
from psycopg2 import sql
from newspaper import Article
import re
from query_db_helper import checkForConflict

#---------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------
""" 
This file is now deprecated.

Prior, it was used to load data from yahoo finance into the postgreSQL database for tables such as ticker, financials, balance_sheet, 
cash_flows, historical prices and ticker news for all 10000 tickers. 
It is no longer used as data_updater.py is used to maintain up to date ticker info in the postgreSQL database.
This code is run manually from the terminal when docker is running.
"""
#---------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------


HOSTNAME="localhost"
DATABASE='stock_data'
USERNAME='postgres'
PASSWORD='postgres'
PORT='9999'
conn = pg.connect(
    host=HOSTNAME,
    user=USERNAME,
    password=PASSWORD,
    dbname=DATABASE,
    port=PORT
)
cursor = conn.cursor()

def camel_to_snake(camel_str):
    return re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', camel_str).lower()

def convert_to_snake_case(text):
    return text.replace(" ", "_").lower()

def get_table_columns(cursor, table_name):
    cursor.execute(f"SELECT column_name FROM information_schema.columns WHERE table_name = %s", (table_name,))
    return {column[0] for column in cursor.fetchall()}

ticker_columns = get_table_columns(cursor, "ticker")
balance_sheet_columns = get_table_columns(cursor, "balance_sheet")
financials_columns = get_table_columns(cursor, "financials")
cash_flow_columns = get_table_columns(cursor, "cash_flow")
location_columns = get_table_columns(cursor, "location")
person_columns = get_table_columns(cursor, "person")


ticker_list = pd.read_excel("TICKERS.xlsx", "TICKERS").iloc[:, 0].tolist()
ticker_list = [str(ticker).strip().upper() for ticker in ticker_list]
#--------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------
ticker_list = yf.Tickers(ticker_list)  # got up to 2421 + 1051, also need to reupdate the on conflict thing to update did 2720
#--------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------

ticker_list = ticker_list.tickers.items()
count = 1
for symbol, ticker in ticker_list:

    print(count)
    print(symbol)
    count = count + 1

    ticker_id = symbol
    
    # ticker table
    try:
        info = ticker.info
    except Exception as e:
        print(f"Error fetching info for {symbol}: {e}")
        continue 
    
    info = {camel_to_snake(k): v for k, v in info.items()}
    for key, value in info.items():
                if isinstance(value, dict) or isinstance(value, list):
                    info[key] = json.dumps(value)
    info.update({
        "ticker_id": ticker_id
    })

    info = {key: value for key, value in info.items() if key in ticker_columns}

    columns = info.keys()
    values = tuple(info.values())

    insert_query = sql.SQL("INSERT INTO ticker ({}) VALUES ({}) ON CONFLICT (ticker_id) DO NOTHING").format(
        sql.SQL(', ').join(map(sql.Identifier, columns)),
        sql.SQL(', ').join(sql.Placeholder() * len(values))
    )

    cursor.execute(insert_query, values)

    # balance_sheet table
    balance_sheet = ticker.balance_sheet
    balance_sheets = []
    i = 0
    for date in balance_sheet.columns:
        balance_sheet_by_date = balance_sheet[date].to_dict()
        balance_sheet_by_date = {convert_to_snake_case(k): v for k, v in balance_sheet_by_date.items()}
        balance_sheet_by_date.update({
             "date": str(date)
        })
        balance_sheets.append(balance_sheet_by_date)
        i = i + 1
        if (i == 3):
             break

    for sheet in balance_sheets:
        for key, value in sheet.items():
            if isinstance(value, dict) or isinstance(value, list):
                balance_sheet[key] = json.dumps(value)
        sheet.update({
            "ticker_id": ticker_id
        })

        sheet = {key: value for key, value in sheet.items() if key in balance_sheet_columns}

        columns = sheet.keys()
        values = tuple(sheet.values())

        insert_query = sql.SQL("INSERT INTO balance_sheet ({}) VALUES ({}) ON CONFLICT (ticker_id, date) DO NOTHING").format(
            sql.SQL(', ').join(map(sql.Identifier, columns)),
            sql.SQL(', ').join(sql.Placeholder() * len(values))
        )

        cursor.execute(insert_query, values)

    # financials table
    financials = ticker.financials
    
    financialss = []
    i = 0
    for date in financials.columns:
        financials_by_date = financials[date].to_dict()
        financials_by_date = {convert_to_snake_case(k): v for k, v in financials_by_date.items()}
        financials_by_date.update({
             "date": str(date)
        })
        financialss.append(financials_by_date)
        i = i + 1
        if (i == 3):
             break

    for sheet in financialss:
        for key, value in sheet.items():
            if isinstance(value, dict) or isinstance(value, list):
                financials[key] = json.dumps(value)
        sheet.update({
            "ticker_id": ticker_id
        })

        sheet = {key: value for key, value in sheet.items() if key in financials_columns}

        columns = sheet.keys()
        values = tuple(sheet.values())

        insert_query = sql.SQL("INSERT INTO financials ({}) VALUES ({}) ON CONFLICT (ticker_id, date) DO NOTHING").format(
            sql.SQL(', ').join(map(sql.Identifier, columns)),
            sql.SQL(', ').join(sql.Placeholder() * len(values))
        )

        cursor.execute(insert_query, values)

    # cash_flow table
    cash_flow = ticker.cash_flow
    
    cash_flows = []
    i = 0
    for date in cash_flow.columns:
        cash_flow_by_date = cash_flow[date].to_dict()
        cash_flow_by_date = {convert_to_snake_case(k): v for k, v in cash_flow_by_date.items()}
        cash_flow_by_date.update({
             "date": str(date)
        })
        cash_flows.append(cash_flow_by_date)
        i = i + 1
        if (i == 3):
             break

    for sheet in cash_flows:
        for key, value in sheet.items():
            if isinstance(value, dict) or isinstance(value, list):
                cash_flow[key] = json.dumps(value)
        sheet.update({
            "ticker_id": ticker_id
        })

        sheet = {key: value for key, value in sheet.items() if key in cash_flow_columns}

        columns = sheet.keys()
        values = tuple(sheet.values())

        insert_query = sql.SQL("INSERT INTO cash_flow ({}) VALUES ({}) ON CONFLICT (ticker_id, date) DO NOTHING").format(
            sql.SQL(', ').join(map(sql.Identifier, columns)),
            sql.SQL(', ').join(sql.Placeholder() * len(values))
        )

        cursor.execute(insert_query, values)
        
    # location table
    # person table
    
    # historical_price_data table
    historical_price_data = ticker.history(period='10y')

    records = [(ticker_id, index, float(row['Open']), float(row['High']), float(row['Low']),
            float(row['Close']), int(row['Volume']))
           for index, row in historical_price_data.iterrows()]
    
    insert_data_query = f"""
    INSERT INTO historical_price_data (ticker_id, date, open, high, low, close, volume)
    VALUES (%s, %s, %s, %s, %s, %s, %s)
    ON CONFLICT (ticker_id, date) DO NOTHING;
    """
    cursor.executemany(insert_data_query, records)

    # ticker_news table
    ticker_news = ticker.news
    records = []
    for article in ticker_news:
        content = article['content']
        if checkForConflict(cursor, "ticker_news", ["ticker_id", "title"], (ticker_id, content['title'],)):
            continue
        record = (ticker_id, content['title'], content['pubDate'], content['canonicalUrl']['url'])
        records.append(record)

    insert_data_query = f"""
    INSERT INTO ticker_news (ticker_id, title, published, url)
    VALUES (%s, %s, %s, %s)
    ON CONFLICT (ticker_id, title) DO NOTHING;
    """
    cursor.executemany(insert_data_query, records)

    conn.commit()
cursor.close()
conn.close()
