import React from 'react';
import ReactDOMClient from 'react-dom/client';
import App from '../frontend/src/App';

it('renders as expected', () => {
  const div = document.createElement('div');
  ReactDOMClient.createRoot(div).render(<App />);
});